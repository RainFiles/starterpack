#!/bin/bash

# Ultimate Discord MegaBot - Installation Script
# This script will install and set up the bot automatically

set -e

echo "╔══════════════════════════════════════════════════════╗"
echo "║                                                      ║"
echo "║     ULTIMATE DISCORD MEGABOT - INSTALLER            ║"
echo "║     500+ Commands | All-in-One Bot                  ║"
echo "║                                                      ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Check Node.js version
echo "📋 Checking prerequisites..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed!"
    echo "Please install Node.js 18.0.0 or higher from https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js version 18.0.0 or higher is required!"
    echo "Current version: $(node -v)"
    echo "Please update Node.js from https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js $(node -v) detected"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
npm install
echo "✅ Dependencies installed"
echo ""

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "⚙️  Creating configuration file..."
    cp .env.example .env
    echo "✅ Configuration file created"
    echo ""
    echo "⚠️  IMPORTANT: Edit .env file and add your bot token!"
    echo ""
    echo "To edit the configuration:"
    echo "  nano .env"
    echo ""
    echo "You need to set:"
    echo "  - DISCORD_TOKEN (required)"
    echo "  - OWNER_IDS (your Discord user ID)"
    echo "  - PREFIX (default: !)"
    echo ""
else
    echo "ℹ️  Configuration file already exists"
    echo ""
fi

# Create data directory
mkdir -p data
echo "✅ Data directory created"
echo ""

# Installation complete
echo "╔══════════════════════════════════════════════════════╗"
echo "║                                                      ║"
echo "║            INSTALLATION COMPLETE! ✅                 ║"
echo "║                                                      ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "📝 Next Steps:"
echo ""
echo "1. Edit .env file and add your bot token:"
echo "   nano .env"
echo ""
echo "2. Get your bot token from:"
echo "   https://discord.com/developers/applications"
echo ""
echo "3. Enable these Privileged Gateway Intents:"
echo "   ✅ PRESENCE INTENT"
echo "   ✅ SERVER MEMBERS INTENT"
echo "   ✅ MESSAGE CONTENT INTENT"
echo ""
echo "4. Invite bot to your server with this link:"
echo "   https://discord.com/api/oauth2/authorize?client_id=YOUR_BOT_ID&permissions=8&scope=bot"
echo ""
echo "5. Start the bot:"
echo "   npm start"
echo ""
echo "6. In Discord, run:"
echo "   !help              - View all commands"
echo "   !setup             - Setup wizard"
echo "   !ticketsetup       - Setup tickets"
echo ""
echo "📚 Documentation:"
echo "   - README.md        - Full documentation"
echo "   - START.md         - Quick start guide"
echo "   - COMMANDS.md      - Complete command list"
echo ""
echo "🆘 Need help? Create an issue on GitHub"
echo ""
echo "Thank you for using Ultimate Discord MegaBot! 🤖"
echo ""
