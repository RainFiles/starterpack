# 🤖 Ultimate Discord MegaBot

The most comprehensive all-in-one Discord bot with **500+ commands** combining features from MEE6, Dyno, Carl-bot, Dank Memer, ProBot, and many more popular bots!

## ✨ Features

### 🎫 Advanced Ticket System
- Custom ticket categories with colors and emojis
- Interactive ticket panels
- Ticket claiming and management
- Lock/unlock tickets
- Automatic ticket transcripts
- Multi-category support

### 🛡️ Moderation (100+ Commands)
- **Message Management**: clear, purge, nuke, clean
- **Member Management**: kick, ban, unban, softban, tempban
- **Mute System**: mute, unmute, tempmute
- **Channel Control**: lock, unlock, slowmode, hide, unhide
- **Warning System**: warn, warnings, clearwarns
- **Auto Moderation**: anti-spam, anti-link, anti-raid, bad word filter

### 💰 Economy System (50+ Commands)
- Balance, bank, deposit, withdraw
- Daily, weekly, monthly rewards
- Work, crime, rob, heist
- Shop system with custom items
- Trading and marketplace
- Inventory management
- Casino games: slots, blackjack, roulette, coinflip
- Jobs and salary system

### 📊 Leveling & XP
- Message and voice XP
- Customizable level-up messages
- Level roles
- Leaderboards and rankings
- XP multipliers
- No-gain channels/roles

### 🎮 Games & Fun (100+ Commands)
- **Mini Games**: trivia, truth or dare, would you rather
- **Card Games**: uno, poker, blackjack
- **Board Games**: chess, connect4, tictactoe
- **RPG System**: battles, quests, dungeons
- **Pet System**: adopt, feed, train, battle
- **Marriage System**: marry, divorce
- **Clan/Guild System**: create, join, wars

### 🎵 Music (50+ Commands)
- Play, pause, resume, skip, stop
- Queue management
- Volume control
- Lyrics lookup
- Spotify integration
- Radio stations
- Playlists

### 💻 VPS Management (ADMIN ONLY)
- **!bash** - Execute system commands
- **!sshx** - Create SSH session with web access
- **!tmate** - Alternative SSH sharing
- Server monitoring
- Log viewing
- Process management

### 🔧 Utility (100+ Commands)
- Server info, user info, role info
- Avatar, banner commands
- Reminder system
- Polls and voting
- Suggestions
- AFK status
- Starboard
- Custom commands
- Reaction roles

### 🤖 Automation
- Welcome/goodbye messages
- Auto roles
- Auto moderation
- Auto publish
- Auto reactions
- Scheduled messages

### 📝 Logging
- Message logs (edit/delete)
- Member logs (join/leave)
- Moderation logs
- Voice logs
- Role logs
- Channel logs

## 🚀 Installation

### Prerequisites
- Node.js 18.0.0 or higher
- npm or yarn
- A Discord bot token

### Quick Start

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/ultimate-discord-megabot.git
cd ultimate-discord-megabot
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure the bot**
```bash
cp .env.example .env
```
Edit `.env` and add your bot token and other configuration.

4. **Start the bot**
```bash
npm start
```

For development with auto-reload:
```bash
npm run dev
```

## ⚙️ Configuration

Edit the `.env` file:

```env
# Required
DISCORD_TOKEN=your_bot_token_here
PREFIX=!
OWNER_IDS=your_user_id_here

# Optional
SUPPORT_SERVER=https://discord.gg/your_server
VOTE_LINK=https://top.gg/bot/your_bot_id
```

## 📚 Commands

The bot includes **500+ commands** across multiple categories:

- 🛠️ **Setup** (10 commands)
- 🎫 **Tickets** (15 commands)
- 🛡️ **Moderation** (80 commands)
- 👑 **Admin** (30 commands)
- 🔧 **Utility** (60 commands)
- 🎮 **Fun** (100 commands)
- 💰 **Economy** (70 commands)
- 📊 **Leveling** (20 commands)
- 🎵 **Music** (50 commands)
- 🎲 **Games** (60 commands)
- 👥 **Social** (30 commands)
- 💻 **VPS** (10 commands)
- And many more!

Use `!help` to see all available commands.

## 🎯 First-Time Setup

1. Invite the bot to your server with Administrator permissions
2. Run `!setup` to start the interactive setup wizard
3. Configure ticket system with `!ticketsetup`
4. Set up logging channels
5. Configure welcome/goodbye messages
6. Enable leveling and economy

## 🔐 VPS Commands (Admin Only)

**⚠️ SECURITY WARNING**: These commands provide direct system access and should only be used by trusted server owners.

- `!bash <command>` - Execute bash commands
- `!sshx` - Create web-accessible SSH session
- `!tmate` - Create tmate SSH session
- All VPS commands require Administrator permissions

## 🤝 Support

- Join our [Support Server](https://discord.gg/support)
- Report bugs via GitHub Issues
- Suggest features in our Discord

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🌟 Credits

Inspired by and combines features from:
- MEE6 (Leveling, Moderation)
- Dyno (Auto-mod, Utilities)
- Carl-bot (Reaction Roles, Logging)
- Dank Memer (Economy, Fun)
- ProBot (Welcome, Auto-roles)
- And many other amazing Discord bots!

## 💡 Features Roadmap

- [ ] Web Dashboard
- [ ] Slash Commands
- [ ] More mini-games
- [ ] Advanced analytics
- [ ] Multi-language support
- [ ] Custom embeds builder
- [ ] Advanced permissions system

## 🔄 Updates

Stay updated with the latest features:
- Star this repository
- Join our Discord
- Follow development on GitHub

---

Made with ❤️ by the MegaBot Team
