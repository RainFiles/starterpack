require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection, REST, Routes, ActivityType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const Database = require('./database/Database');
const chalk = require('chalk');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildBans,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildScheduledEvents,
        GatewayIntentBits.AutoModerationConfiguration,
        GatewayIntentBits.AutoModerationExecution,
    ],
    partials: [
        Partials.User,
        Partials.Channel,
        Partials.GuildMember,
        Partials.Message,
        Partials.Reaction,
        Partials.GuildScheduledEvent,
        Partials.ThreadMember,
    ],
    allowedMentions: { parse: ['users', 'roles'], repliedUser: true }
});

// Collections
client.commands = new Collection();
client.cooldowns = new Collection();
client.aliases = new Collection();
client.categories = new Collection();
client.queue = new Map();
client.voiceQueue = new Map();
client.activeGames = new Collection();
client.activePolls = new Collection();
client.activeGiveaways = new Collection();
client.afkUsers = new Collection();
client.sshSessions = new Collection();

// Database
client.db = new Database();

// Configuration
client.config = {
    prefix: process.env.PREFIX || '!',
    token: process.env.DISCORD_TOKEN,
    ownerIDs: process.env.OWNER_IDS?.split(',') || [],
    supportServer: process.env.SUPPORT_SERVER || '',
    voteLink: process.env.VOTE_LINK || '',
    websiteLink: process.env.WEBSITE_LINK || '',
    embedColor: '#FF00FF',
    errorColor: '#FF0000',
    successColor: '#00FF00',
    warningColor: '#FFFF00',
};

// Load command handler
const loadCommands = () => {
    const commandFolders = fs.readdirSync('./commands');
    let commandCount = 0;

    for (const folder of commandFolders) {
        const commandFiles = fs.readdirSync(`./commands/${folder}`).filter(file => file.endsWith('.js'));
        
        for (const file of commandFiles) {
            try {
                const command = require(`./commands/${folder}/${file}`);
                
                if (command.name) {
                    client.commands.set(command.name, command);
                    commandCount++;
                    
                    if (command.aliases && Array.isArray(command.aliases)) {
                        command.aliases.forEach(alias => {
                            client.aliases.set(alias, command.name);
                        });
                    }
                    
                    if (!client.categories.has(folder)) {
                        client.categories.set(folder, []);
                    }
                    client.categories.get(folder).push(command);
                }
            } catch (error) {
                console.error(chalk.red(`Error loading command ${file}:`), error);
            }
        }
    }
    
    console.log(chalk.green(`✓ Loaded ${commandCount} commands from ${commandFolders.length} categories`));
};

// Load event handler
const loadEvents = () => {
    const eventFiles = fs.readdirSync('./events').filter(file => file.endsWith('.js'));
    let eventCount = 0;

    for (const file of eventFiles) {
        try {
            const event = require(`./events/${file}`);
            const eventName = file.split('.')[0];
            
            if (event.once) {
                client.once(eventName, (...args) => event.execute(...args, client));
            } else {
                client.on(eventName, (...args) => event.execute(...args, client));
            }
            eventCount++;
        } catch (error) {
            console.error(chalk.red(`Error loading event ${file}:`), error);
        }
    }
    
    console.log(chalk.green(`✓ Loaded ${eventCount} events`));
};

// Initialize bot
const initialize = async () => {
    console.log(chalk.cyan('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
    console.log(chalk.magenta.bold('      ULTIMATE DISCORD MEGABOT'));
    console.log(chalk.cyan('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
    
    // Initialize database
    console.log(chalk.yellow('⏳ Initializing database...'));
    await client.db.init();
    
    // Load commands and events
    console.log(chalk.yellow('⏳ Loading commands...'));
    loadCommands();
    
    console.log(chalk.yellow('⏳ Loading events...'));
    loadEvents();
    
    // Login
    console.log(chalk.yellow('⏳ Logging in...'));
    await client.login(client.config.token);
};

// Error handling
process.on('unhandledRejection', error => {
    console.error(chalk.red('Unhandled promise rejection:'), error);
});

process.on('uncaughtException', error => {
    console.error(chalk.red('Uncaught exception:'), error);
});

// Graceful shutdown
process.on('SIGINT', async () => {
    console.log(chalk.yellow('\n⏳ Shutting down gracefully...'));
    await client.db.close();
    client.destroy();
    process.exit(0);
});

// Start bot
initialize().catch(error => {
    console.error(chalk.red('Failed to initialize bot:'), error);
    process.exit(1);
});

module.exports = client;
