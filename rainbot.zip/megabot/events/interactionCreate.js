const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (!interaction.isButton()) return;

        // Handle ticket creation
        if (interaction.customId.startsWith('ticket_create_')) {
            await handleTicketCreate(interaction, client);
        }
        
        // Handle ticket actions
        else if (interaction.customId === 'ticket_lock') {
            await handleTicketLock(interaction, client);
        }
        else if (interaction.customId === 'ticket_unlock') {
            await handleTicketUnlock(interaction, client);
        }
        else if (interaction.customId === 'ticket_claim') {
            await handleTicketClaim(interaction, client);
        }
        else if (interaction.customId === 'ticket_delete') {
            await handleTicketDelete(interaction, client);
        }
    }
};

async function handleTicketCreate(interaction, client) {
    await interaction.deferReply({ ephemeral: true });

    const guildData = client.db.getGuild(interaction.guild.id);
    
    // Check if user already has open ticket
    const existingTicket = client.db.db.prepare(`
        SELECT * FROM tickets 
        WHERE guild_id = ? AND user_id = ? AND status = 'open'
    `).get(interaction.guild.id, interaction.user.id);

    if (existingTicket) {
        return interaction.editReply({
            content: `❌ You already have an open ticket: <#${existingTicket.channel_id}>`,
            ephemeral: true
        });
    }

    // Get category
    const categoryId = interaction.customId.replace('ticket_create_', '');
    const category = client.db.db.prepare(`
        SELECT * FROM ticket_categories 
        WHERE guild_id = ? AND id = ?
    `).get(interaction.guild.id, categoryId) || { name: 'general', emoji: '🎫' };

    // Increment ticket counter
    const ticketNumber = guildData.ticket_counter + 1;
    client.db.updateGuild(interaction.guild.id, { ticket_counter: ticketNumber });

    // Create ticket channel
    try {
        const ticketChannel = await interaction.guild.channels.create({
            name: `ticket-${ticketNumber}-${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: guildData.ticket_category || null,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel],
                },
                {
                    id: interaction.user.id,
                    allow: [
                        PermissionsBitField.Flags.ViewChannel,
                        PermissionsBitField.Flags.SendMessages,
                        PermissionsBitField.Flags.AttachFiles,
                        PermissionsBitField.Flags.ReadMessageHistory
                    ],
                },
                {
                    id: interaction.guild.members.me.roles.highest.id,
                    allow: [
                        PermissionsBitField.Flags.ViewChannel,
                        PermissionsBitField.Flags.SendMessages,
                        PermissionsBitField.Flags.ManageChannels
                    ],
                }
            ]
        });

        // Create ticket embed
        const ticketEmbed = new EmbedBuilder()
            .setTitle(`${category.emoji || '🎫'} Ticket Opened`)
            .setDescription(`Welcome <@${interaction.user.id}>!\nStaff will assist you shortly.`)
            .addFields(
                { name: 'Opened by:', value: `<@${interaction.user.id}> ( ${interaction.user.id} )` },
                { name: 'Category:', value: category.name }
            )
            .setColor('#00FF00')
            .setTimestamp();

        const ticketRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_lock')
                    .setLabel('🔒 Lock')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('ticket_unlock')
                    .setLabel('🔓 Unlock')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('ticket_claim')
                    .setLabel('✋ Claim')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('ticket_delete')
                    .setLabel('🗑️ Delete')
                    .setStyle(ButtonStyle.Danger)
            );

        await ticketChannel.send({
            content: `<@${interaction.user.id}>`,
            embeds: [ticketEmbed],
            components: [ticketRow]
        });

        // Save to database
        const stmt = client.db.db.prepare(`
            INSERT INTO tickets (guild_id, channel_id, user_id, category, status)
            VALUES (?, ?, ?, ?, 'open')
        `);
        stmt.run(interaction.guild.id, ticketChannel.id, interaction.user.id, category.name);

        await interaction.editReply({
            content: `✅ Ticket created: ${ticketChannel}`,
            ephemeral: true
        });

    } catch (error) {
        console.error('Error creating ticket:', error);
        await interaction.editReply({
            content: '❌ Failed to create ticket. Please contact an administrator.',
            ephemeral: true
        });
    }
}

async function handleTicketLock(interaction, client) {
    const ticket = client.db.db.prepare(`
        SELECT * FROM tickets WHERE channel_id = ? AND status = 'open'
    `).get(interaction.channel.id);

    if (!ticket) {
        return interaction.reply({
            content: '❌ This is not a valid ticket channel!',
            ephemeral: true
        });
    }

    // Lock channel
    await interaction.channel.permissionOverwrites.edit(ticket.user_id, {
        SendMessages: false
    });

    await interaction.reply({
        embeds: [{
            title: '🔒 Ticket Locked',
            description: `Ticket locked by ${interaction.user}`,
            color: 0xFFFF00
        }]
    });
}

async function handleTicketUnlock(interaction, client) {
    const ticket = client.db.db.prepare(`
        SELECT * FROM tickets WHERE channel_id = ? AND status = 'open'
    `).get(interaction.channel.id);

    if (!ticket) {
        return interaction.reply({
            content: '❌ This is not a valid ticket channel!',
            ephemeral: true
        });
    }

    // Unlock channel
    await interaction.channel.permissionOverwrites.edit(ticket.user_id, {
        SendMessages: true
    });

    await interaction.reply({
        embeds: [{
            title: '🔓 Ticket Unlocked',
            description: `Ticket unlocked by ${interaction.user}`,
            color: 0x00FF00
        }]
    });
}

async function handleTicketClaim(interaction, client) {
    const ticket = client.db.db.prepare(`
        SELECT * FROM tickets WHERE channel_id = ? AND status = 'open'
    `).get(interaction.channel.id);

    if (!ticket) {
        return interaction.reply({
            content: '❌ This is not a valid ticket channel!',
            ephemeral: true
        });
    }

    if (ticket.claimed_by) {
        return interaction.reply({
            content: `❌ This ticket has already been claimed by <@${ticket.claimed_by}>!`,
            ephemeral: true
        });
    }

    // Claim ticket
    const stmt = client.db.db.prepare(`
        UPDATE tickets SET claimed_by = ? WHERE channel_id = ?
    `);
    stmt.run(interaction.user.id, interaction.channel.id);

    await interaction.reply({
        embeds: [{
            title: '✋ Ticket Claimed',
            description: `Ticket claimed by ${interaction.user}`,
            color: 0x0000FF
        }]
    });
}

async function handleTicketDelete(interaction, client) {
    const ticket = client.db.db.prepare(`
        SELECT * FROM tickets WHERE channel_id = ?
    `).get(interaction.channel.id);

    if (!ticket) {
        return interaction.reply({
            content: '❌ This is not a valid ticket channel!',
            ephemeral: true
        });
    }

    await interaction.reply({
        embeds: [{
            title: '🗑️ Closing Ticket',
            description: 'This ticket will be deleted in 5 seconds...',
            color: 0xFF0000
        }]
    });

    // Update database
    const stmt = client.db.db.prepare(`
        UPDATE tickets SET status = 'closed', closed_at = datetime('now') WHERE channel_id = ?
    `);
    stmt.run(interaction.channel.id);

    // Delete channel after delay
    setTimeout(async () => {
        try {
            await interaction.channel.delete();
        } catch (error) {
            console.error('Error deleting ticket channel:', error);
        }
    }, 5000);
}
