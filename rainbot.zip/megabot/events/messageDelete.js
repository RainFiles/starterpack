const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'messageDelete',
    async execute(message, client) {
        if (!message.guild || message.author?.bot) return;

        const guildData = client.db.getGuild(message.guild.id);

        if (guildData.message_log_channel) {
            const logChannel = message.guild.channels.cache.get(guildData.message_log_channel);
            
            if (logChannel && message.content) {
                const embed = new EmbedBuilder()
                    .setTitle('🗑️ Message Deleted')
                    .setDescription(`Message deleted in ${message.channel}`)
                    .addFields(
                        { name: 'Author', value: `${message.author?.tag || 'Unknown'}`, inline: true },
                        { name: 'Channel', value: `${message.channel}`, inline: true },
                        { name: 'Content', value: message.content.substring(0, 1024) || 'No content' }
                    )
                    .setColor('#FF0000')
                    .setTimestamp();

                await logChannel.send({ embeds: [embed] }).catch(() => {});
            }
        }
    }
};
