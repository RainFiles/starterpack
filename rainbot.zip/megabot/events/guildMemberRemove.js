const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildMemberRemove',
    async execute(member, client) {
        const guildData = client.db.getGuild(member.guild.id);

        // Goodbye message
        if (guildData.goodbye_enabled && guildData.goodbye_channel) {
            const channel = member.guild.channels.cache.get(guildData.goodbye_channel);
            
            if (channel) {
                const message = (guildData.goodbye_message || 'Goodbye {user}! We hope to see you again.')
                    .replace('{user}', member.user.tag)
                    .replace('{server}', member.guild.name);

                const embed = new EmbedBuilder()
                    .setTitle('👋 Goodbye!')
                    .setDescription(message)
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setColor('#FF0000')
                    .setTimestamp();

                await channel.send({ embeds: [embed] }).catch(() => {});
            }
        }

        // Leave log
        if (guildData.leave_log_channel) {
            const logChannel = member.guild.channels.cache.get(guildData.leave_log_channel);
            
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('📤 Member Left')
                    .setDescription(`${member.user.tag} left the server`)
                    .addFields(
                        { name: 'User', value: `${member.user.tag}`, inline: true },
                        { name: 'ID', value: member.id, inline: true },
                        { name: 'Joined', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setColor('#FF0000')
                    .setFooter({ text: `${member.guild.memberCount} members remaining` })
                    .setTimestamp();

                await logChannel.send({ embeds: [embed] }).catch(() => {});
            }
        }
    }
};
