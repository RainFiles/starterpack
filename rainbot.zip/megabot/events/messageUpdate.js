const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'messageUpdate',
    async execute(oldMessage, newMessage, client) {
        if (!newMessage.guild || newMessage.author?.bot) return;
        if (oldMessage.content === newMessage.content) return;

        const guildData = client.db.getGuild(newMessage.guild.id);

        if (guildData.message_log_channel) {
            const logChannel = newMessage.guild.channels.cache.get(guildData.message_log_channel);
            
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('✏️ Message Edited')
                    .setDescription(`Message edited in ${newMessage.channel}`)
                    .addFields(
                        { name: 'Author', value: `${newMessage.author.tag}`, inline: true },
                        { name: 'Channel', value: `${newMessage.channel}`, inline: true },
                        { name: 'Before', value: oldMessage.content?.substring(0, 1024) || 'No content' },
                        { name: 'After', value: newMessage.content.substring(0, 1024) }
                    )
                    .setColor('#FFFF00')
                    .setTimestamp();

                await logChannel.send({ embeds: [embed] }).catch(() => {});
            }
        }
    }
};
