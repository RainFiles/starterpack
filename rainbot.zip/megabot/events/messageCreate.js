const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        if (message.author.bot) return;
        if (!message.guild) return;

        // Get guild settings
        const guildData = client.db.getGuild(message.guild.id);
        const prefix = guildData.prefix || client.config.prefix;

        // Check AFK status
        await checkAFK(message, client);

        // Add XP for messages (if leveling enabled)
        if (guildData.level_enabled) {
            const xpGained = Math.floor(Math.random() * 15) + 10;
            const result = client.db.addXP(message.author.id, message.guild.id, xpGained);
            
            if (result.leveledUp && guildData.level_channel) {
                const channel = message.guild.channels.cache.get(guildData.level_channel) || message.channel;
                const levelMessage = guildData.level_message || 'GG {user}, you just advanced to level {level}!';
                
                channel.send({
                    content: levelMessage
                        .replace('{user}', `<@${message.author.id}>`)
                        .replace('{level}', result.newLevel)
                }).catch(() => {});
            }
        }

        // Check for commands
        if (!message.content.startsWith(prefix)) return;

        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        const command = client.commands.get(commandName) || 
                       client.commands.get(client.aliases.get(commandName));

        if (!command) return;

        // Check permissions
        if (command.permissions && command.permissions.length > 0) {
            const memberPerms = message.member.permissions;
            const hasPerms = command.permissions.every(perm => memberPerms.has(PermissionsBitField.Flags[perm]));
            
            if (!hasPerms) {
                return message.reply({
                    embeds: [{
                        title: '❌ Missing Permissions',
                        description: `You need the following permissions: ${command.permissions.join(', ')}`,
                        color: 0xFF0000
                    }]
                });
            }
        }

        // Check bot permissions
        if (command.botPermissions && command.botPermissions.length > 0) {
            const botPerms = message.guild.members.me.permissions;
            const hasPerms = command.botPermissions.every(perm => botPerms.has(PermissionsBitField.Flags[perm]));
            
            if (!hasPerms) {
                return message.reply({
                    embeds: [{
                        title: '❌ Bot Missing Permissions',
                        description: `I need the following permissions: ${command.botPermissions.join(', ')}`,
                        color: 0xFF0000
                    }]
                });
            }
        }

        // Check owner only
        if (command.ownerOnly && !client.config.ownerIDs.includes(message.author.id)) {
            return message.reply('❌ This command is only available to bot owners!');
        }

        // Cooldown check
        if (command.cooldown) {
            if (!client.cooldowns.has(command.name)) {
                client.cooldowns.set(command.name, new Map());
            }

            const now = Date.now();
            const timestamps = client.cooldowns.get(command.name);
            const cooldownAmount = command.cooldown * 1000;

            if (timestamps.has(message.author.id)) {
                const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

                if (now < expirationTime) {
                    const timeLeft = (expirationTime - now) / 1000;
                    return message.reply({
                        embeds: [{
                            description: `⏰ Please wait ${timeLeft.toFixed(1)} more seconds before using \`${command.name}\` again.`,
                            color: 0xFFFF00
                        }]
                    }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));
                }
            }

            timestamps.set(message.author.id, now);
            setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);
        }

        // Log command usage
        try {
            const stmt = client.db.db.prepare(`
                INSERT INTO command_stats (command, guild_id, user_id, uses, last_used) 
                VALUES (?, ?, ?, 1, datetime('now'))
                ON CONFLICT(command, guild_id, user_id) 
                DO UPDATE SET uses = uses + 1, last_used = datetime('now')
            `);
            stmt.run(command.name, message.guild.id, message.author.id);
        } catch (error) {
            console.error('Error logging command usage:', error);
        }

        // Execute command
        try {
            await command.execute(message, args, client);
        } catch (error) {
            console.error(`Error executing ${command.name}:`, error);
            message.reply({
                embeds: [{
                    title: '❌ Command Error',
                    description: 'There was an error executing this command!',
                    color: 0xFF0000
                }]
            }).catch(() => {});
        }
    }
};

async function checkAFK(message, client) {
    // Check if author is AFK
    const stmt = client.db.db.prepare('SELECT * FROM afk WHERE user_id = ?');
    const afk = stmt.get(message.author.id);
    
    if (afk) {
        const deleteStmt = client.db.db.prepare('DELETE FROM afk WHERE user_id = ?');
        deleteStmt.run(message.author.id);
        
        const duration = Math.floor((Date.now() - new Date(afk.started_at).getTime()) / 1000);
        const hours = Math.floor(duration / 3600);
        const minutes = Math.floor((duration % 3600) / 60);
        
        message.reply({
            embeds: [{
                description: `👋 Welcome back! You were AFK for ${hours}h ${minutes}m`,
                color: 0x00FF00
            }]
        }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));
    }

    // Check if mentioned users are AFK
    message.mentions.users.forEach(user => {
        if (user.bot) return;
        const userAfk = stmt.get(user.id);
        
        if (userAfk) {
            message.reply({
                embeds: [{
                    description: `💤 ${user.username} is currently AFK: ${userAfk.reason || 'No reason provided'}`,
                    color: 0xFFFF00
                }]
            }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 10000));
        }
    });
}
