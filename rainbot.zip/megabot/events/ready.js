const { ActivityType } = require('discord.js');
const chalk = require('chalk');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log(chalk.cyan('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
        console.log(chalk.green.bold(`✓ Bot is online as ${client.user.tag}`));
        console.log(chalk.cyan(`✓ Serving ${client.guilds.cache.size} servers`));
        console.log(chalk.cyan(`✓ Watching ${client.users.cache.size} users`));
        console.log(chalk.cyan(`✓ Loaded ${client.commands.size} commands`));
        console.log(chalk.cyan('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));

        // Set bot status
        const activities = [
            { name: '!help | Ultimate MegaBot', type: ActivityType.Playing },
            { name: `${client.guilds.cache.size} servers`, type: ActivityType.Watching },
            { name: '!setup to get started', type: ActivityType.Listening },
            { name: 'with 500+ commands', type: ActivityType.Playing },
            { name: 'tickets, economy, games & more!', type: ActivityType.Playing },
        ];

        let i = 0;
        setInterval(() => {
            client.user.setActivity(activities[i]);
            i = (i + 1) % activities.length;
        }, 15000);

        // Start reminder checker
        setInterval(() => checkReminders(client), 10000);
        
        // Start giveaway checker
        setInterval(() => checkGiveaways(client), 15000);
        
        // Start temporary actions checker (mutes, bans)
        setInterval(() => checkTempActions(client), 20000);
    }
};

async function checkReminders(client) {
    try {
        const stmt = client.db.db.prepare(`
            SELECT * FROM reminders 
            WHERE completed = 0 AND datetime(remind_at) <= datetime('now')
        `);
        const reminders = stmt.all();

        for (const reminder of reminders) {
            try {
                const channel = await client.channels.fetch(reminder.channel_id);
                if (channel) {
                    await channel.send({
                        content: `<@${reminder.user_id}>`,
                        embeds: [{
                            title: '⏰ Reminder',
                            description: reminder.message,
                            color: 0xFFFF00,
                            footer: { text: `Reminder set ${new Date(reminder.created_at).toLocaleString()}` }
                        }]
                    });
                }
                
                const update = client.db.db.prepare('UPDATE reminders SET completed = 1 WHERE id = ?');
                update.run(reminder.id);
            } catch (error) {
                console.error('Error processing reminder:', error);
            }
        }
    } catch (error) {
        console.error('Error checking reminders:', error);
    }
}

async function checkGiveaways(client) {
    try {
        const stmt = client.db.db.prepare(`
            SELECT * FROM giveaways 
            WHERE ended = 0 AND datetime(ends_at) <= datetime('now')
        `);
        const giveaways = stmt.all();

        for (const giveaway of giveaways) {
            try {
                const channel = await client.channels.fetch(giveaway.channel_id);
                const message = await channel.messages.fetch(giveaway.message_id);
                
                const reaction = message.reactions.cache.get('🎉');
                if (reaction) {
                    const users = await reaction.users.fetch();
                    const validUsers = users.filter(u => !u.bot);
                    
                    if (validUsers.size > 0) {
                        const winners = validUsers.random(Math.min(giveaway.winners, validUsers.size));
                        const winnerList = Array.isArray(winners) ? winners : [winners];
                        
                        await channel.send({
                            content: `🎉 **Giveaway Ended!** 🎉\n\nWinner(s): ${winnerList.map(w => `<@${w.id}>`).join(', ')}\nPrize: **${giveaway.prize}**`
                        });
                        
                        await message.edit({
                            embeds: [{
                                title: '🎉 GIVEAWAY ENDED 🎉',
                                description: `Prize: **${giveaway.prize}**\n\nWinner(s):\n${winnerList.map(w => `<@${w.id}>`).join('\n')}`,
                                color: 0xFF0000,
                                footer: { text: `Ended at` },
                                timestamp: new Date()
                            }]
                        });
                    } else {
                        await channel.send('❌ No valid participants for this giveaway!');
                    }
                }
                
                const update = client.db.db.prepare('UPDATE giveaways SET ended = 1 WHERE id = ?');
                update.run(giveaway.id);
            } catch (error) {
                console.error('Error ending giveaway:', error);
            }
        }
    } catch (error) {
        console.error('Error checking giveaways:', error);
    }
}

async function checkTempActions(client) {
    try {
        const stmt = client.db.db.prepare(`
            SELECT * FROM users 
            WHERE muted = 1 AND datetime(mute_expires) <= datetime('now')
        `);
        const mutedUsers = stmt.all();

        for (const user of mutedUsers) {
            try {
                const guild = await client.guilds.fetch(user.guild_id);
                const member = await guild.members.fetch(user.user_id);
                const muteRole = guild.roles.cache.find(r => r.name === 'Muted');
                
                if (muteRole && member.roles.cache.has(muteRole.id)) {
                    await member.roles.remove(muteRole);
                }
                
                client.db.updateUser(user.user_id, user.guild_id, { 
                    muted: 0, 
                    mute_expires: null 
                });
            } catch (error) {
                console.error('Error unmuting user:', error);
            }
        }
    } catch (error) {
        console.error('Error checking temp actions:', error);
    }
}
