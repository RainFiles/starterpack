const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildMemberAdd',
    async execute(member, client) {
        const guildData = client.db.getGuild(member.guild.id);

        // Welcome message
        if (guildData.welcome_enabled && guildData.welcome_channel) {
            const channel = member.guild.channels.cache.get(guildData.welcome_channel);
            
            if (channel) {
                const message = (guildData.welcome_message || 'Welcome {user} to {server}! You are member #{count}')
                    .replace('{user}', `<@${member.id}>`)
                    .replace('{server}', member.guild.name)
                    .replace('{count}', member.guild.memberCount);

                const embed = new EmbedBuilder()
                    .setTitle('👋 Welcome!')
                    .setDescription(message)
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setColor('#00FF00')
                    .setTimestamp();

                await channel.send({ embeds: [embed] }).catch(() => {});
            }
        }

        // Auto role
        if (guildData.autorole_enabled && guildData.autorole_id) {
            const role = member.guild.roles.cache.get(guildData.autorole_id);
            if (role) {
                await member.roles.add(role).catch(() => {});
            }
        }

        // Join log
        if (guildData.join_log_channel) {
            const logChannel = member.guild.channels.cache.get(guildData.join_log_channel);
            
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('📥 Member Joined')
                    .setDescription(`${member.user.tag} joined the server`)
                    .addFields(
                        { name: 'User', value: `<@${member.id}>`, inline: true },
                        { name: 'ID', value: member.id, inline: true },
                        { name: 'Account Created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setColor('#00FF00')
                    .setFooter({ text: `Member #${member.guild.memberCount}` })
                    .setTimestamp();

                await logChannel.send({ embeds: [embed] }).catch(() => {});
            }
        }
    }
};
