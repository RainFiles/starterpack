const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'poll',
    aliases: ['vote', 'createpoll'],
    description: 'Create a poll',
    usage: '<question> | <option1> | <option2> | ...',
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Usage: `!poll <question> | <option1> | <option2> | ...`');
        }

        const pollData = args.join(' ').split('|').map(s => s.trim());
        
        if (pollData.length < 3) {
            return message.reply('❌ Please provide a question and at least 2 options!');
        }

        const question = pollData[0];
        const options = pollData.slice(1);

        if (options.length > 10) {
            return message.reply('❌ Maximum 10 options allowed!');
        }

        const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
        
        let description = '';
        options.forEach((opt, i) => {
            description += `${emojis[i]} ${opt}\n`;
        });

        const embed = new EmbedBuilder()
            .setTitle('📊 ' + question)
            .setDescription(description)
            .setColor('#FF00FF')
            .setFooter({ text: `Poll by ${message.author.tag}` })
            .setTimestamp();

        const pollMsg = await message.channel.send({ embeds: [embed] });

        for (let i = 0; i < options.length; i++) {
            await pollMsg.react(emojis[i]);
        }

        // Save to database
        const stmt = client.db.db.prepare(`
            INSERT INTO polls (guild_id, channel_id, message_id, question, options, creator_id)
            VALUES (?, ?, ?, ?, ?, ?)
        `);
        stmt.run(
            message.guild.id,
            message.channel.id,
            pollMsg.id,
            question,
            JSON.stringify(options),
            message.author.id
        );

        await message.delete().catch(() => {});
    }
};
