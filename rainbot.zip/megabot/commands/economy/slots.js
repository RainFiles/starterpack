const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'slots',
    aliases: ['slot', 'slotmachine'],
    description: 'Play the slot machine',
    usage: '<bet>',
    cooldown: 10,
    async execute(message, args, client) {
        if (!args[0]) {
            return message.reply('❌ Usage: `!slots <bet>`');
        }

        const bet = parseInt(args[0]);
        const userData = client.db.getUser(message.author.id, message.guild.id);

        if (isNaN(bet) || bet < 10) {
            return message.reply('❌ Minimum bet is 10 coins!');
        }

        if (bet > userData.coins) {
            return message.reply('❌ You don\'t have enough coins!');
        }

        const symbols = ['🍒', '🍋', '🍊', '🍇', '💎', '7️⃣'];
        const results = [
            symbols[Math.floor(Math.random() * symbols.length)],
            symbols[Math.floor(Math.random() * symbols.length)],
            symbols[Math.floor(Math.random() * symbols.length)]
        ];

        let winAmount = 0;
        let winMessage = '';

        if (results[0] === results[1] && results[1] === results[2]) {
            if (results[0] === '💎') {
                winAmount = bet * 10;
                winMessage = '💎 JACKPOT! 10x multiplier!';
            } else if (results[0] === '7️⃣') {
                winAmount = bet * 7;
                winMessage = '🎰 Lucky 7s! 7x multiplier!';
            } else {
                winAmount = bet * 3;
                winMessage = '🎉 Three of a kind! 3x multiplier!';
            }
        } else if (results[0] === results[1] || results[1] === results[2] || results[0] === results[2]) {
            winAmount = bet * 1.5;
            winMessage = '✨ Two of a kind! 1.5x multiplier!';
        } else {
            winAmount = -bet;
            winMessage = '😢 No match! Better luck next time!';
        }

        client.db.updateUser(message.author.id, message.guild.id, {
            coins: userData.coins + winAmount
        });

        const embed = new EmbedBuilder()
            .setTitle('🎰 Slot Machine')
            .setDescription(`${results.join(' | ')}\n\n${winMessage}`)
            .addFields(
                { name: '💰 Bet', value: `${bet} coins`, inline: true },
                { name: '🎁 Win/Loss', value: `${winAmount > 0 ? '+' : ''}${Math.floor(winAmount)} coins`, inline: true },
                { name: '💵 Balance', value: `${(userData.coins + winAmount).toLocaleString()} coins`, inline: true }
            )
            .setColor(winAmount > 0 ? '#00FF00' : '#FF0000')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
