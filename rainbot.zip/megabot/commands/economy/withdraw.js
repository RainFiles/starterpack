const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'withdraw',
    aliases: ['with', 'wd'],
    description: 'Withdraw coins from your bank',
    usage: '<amount|all>',
    async execute(message, args, client) {
        const userData = client.db.getUser(message.author.id, message.guild.id);

        if (!args[0]) {
            return message.reply('❌ Usage: `!withdraw <amount|all>`');
        }

        let amount;
        if (args[0].toLowerCase() === 'all') {
            amount = userData.bank;
        } else {
            amount = parseInt(args[0]);
        }

        if (isNaN(amount) || amount < 1) {
            return message.reply('❌ Please provide a valid amount!');
        }

        if (amount > userData.bank) {
            return message.reply('❌ You don\'t have enough coins in your bank!');
        }

        client.db.updateUser(message.author.id, message.guild.id, {
            coins: userData.coins + amount,
            bank: userData.bank - amount
        });

        const embed = new EmbedBuilder()
            .setTitle('💵 Withdrawal Successful')
            .setDescription(`Withdrew **${amount.toLocaleString()}** coins from your bank!`)
            .addFields(
                { name: '💵 Wallet', value: `${(userData.coins + amount).toLocaleString()}`, inline: true },
                { name: '🏦 Bank', value: `${(userData.bank - amount).toLocaleString()}`, inline: true }
            )
            .setColor('#00FF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
