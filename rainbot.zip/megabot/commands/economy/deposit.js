const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'deposit',
    aliases: ['dep'],
    description: 'Deposit coins into your bank',
    usage: '<amount|all>',
    async execute(message, args, client) {
        const userData = client.db.getUser(message.author.id, message.guild.id);

        if (!args[0]) {
            return message.reply('❌ Usage: `!deposit <amount|all>`');
        }

        let amount;
        if (args[0].toLowerCase() === 'all') {
            amount = userData.coins;
        } else {
            amount = parseInt(args[0]);
        }

        if (isNaN(amount) || amount < 1) {
            return message.reply('❌ Please provide a valid amount!');
        }

        if (amount > userData.coins) {
            return message.reply('❌ You don\'t have enough coins in your wallet!');
        }

        client.db.updateUser(message.author.id, message.guild.id, {
            coins: userData.coins - amount,
            bank: userData.bank + amount
        });

        const embed = new EmbedBuilder()
            .setTitle('🏦 Deposit Successful')
            .setDescription(`Deposited **${amount.toLocaleString()}** coins into your bank!`)
            .addFields(
                { name: '💵 Wallet', value: `${(userData.coins - amount).toLocaleString()}`, inline: true },
                { name: '🏦 Bank', value: `${(userData.bank + amount).toLocaleString()}`, inline: true }
            )
            .setColor('#00FF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
