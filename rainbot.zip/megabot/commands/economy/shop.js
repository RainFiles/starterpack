const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'shop',
    aliases: ['store'],
    description: 'View the server shop',
    async execute(message, args, client) {
        const stmt = client.db.db.prepare(`
            SELECT * FROM shop_items WHERE guild_id = ? ORDER BY price ASC
        `);
        const items = stmt.all(message.guild.id);

        if (!items.length) {
            return message.reply('🏪 The shop is empty! Admins can add items with `!additem`');
        }

        let description = '';
        items.forEach((item, i) => {
            const stock = item.stock === -1 ? '∞' : item.stock;
            description += `**${i + 1}. ${item.name}** - ${item.price.toLocaleString()} coins\n`;
            description += `${item.description || 'No description'}\n`;
            description += `Stock: ${stock}\n\n`;
        });

        const embed = new EmbedBuilder()
            .setTitle('🏪 Server Shop')
            .setDescription(description)
            .setColor('#FFD700')
            .setFooter({ text: 'Use !buy <item name> to purchase' })
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
