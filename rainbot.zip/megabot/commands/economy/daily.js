const { EmbedBuilder } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'daily',
    aliases: ['dailyreward', 'claim'],
    description: 'Claim your daily reward',
    cooldown: 86400, // 24 hours
    async execute(message, args, client) {
        const userData = client.db.getUser(message.author.id, message.guild.id);
        
        const now = Date.now();
        const lastDaily = userData.last_daily ? new Date(userData.last_daily).getTime() : 0;
        const cooldown = 24 * 60 * 60 * 1000; // 24 hours

        if (now - lastDaily < cooldown) {
            const timeLeft = cooldown - (now - lastDaily);
            return message.reply({
                embeds: [{
                    title: '⏰ Daily Cooldown',
                    description: `You can claim your daily reward in **${ms(timeLeft, { long: true })}**`,
                    color: 0xFFFF00
                }]
            });
        }

        // Calculate reward
        const baseReward = 1000;
        const streakBonus = userData.daily_streak * 100;
        const totalReward = baseReward + streakBonus;

        // Update streak
        const oneDayAgo = now - (25 * 60 * 60 * 1000); // 25 hours grace period
        const newStreak = lastDaily > oneDayAgo ? userData.daily_streak + 1 : 1;

        // Update user data
        client.db.updateUser(message.author.id, message.guild.id, {
            coins: userData.coins + totalReward,
            daily_streak: newStreak,
            last_daily: new Date().toISOString()
        });

        const embed = new EmbedBuilder()
            .setTitle('🎁 Daily Reward Claimed!')
            .setDescription(`You received **${totalReward.toLocaleString()}** coins!`)
            .addFields(
                { name: '💵 Base Reward', value: `${baseReward.toLocaleString()} coins`, inline: true },
                { name: '🔥 Streak Bonus', value: `${streakBonus.toLocaleString()} coins`, inline: true },
                { name: '📊 Current Streak', value: `${newStreak} days`, inline: true },
                { name: '💰 New Balance', value: `${(userData.coins + totalReward).toLocaleString()} coins` }
            )
            .setColor('#00FF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
