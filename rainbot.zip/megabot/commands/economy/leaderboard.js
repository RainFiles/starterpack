const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'baltop',
    aliases: ['leaderboard', 'richest', 'top'],
    description: 'View the richest users',
    async execute(message, args, client) {
        const stmt = client.db.db.prepare(`
            SELECT user_id, coins, bank 
            FROM users 
            WHERE guild_id = ? 
            ORDER BY (coins + bank) DESC 
            LIMIT 10
        `);
        const topUsers = stmt.all(message.guild.id);

        if (!topUsers.length) {
            return message.reply('❌ No economy data available!');
        }

        let description = '';
        for (let i = 0; i < topUsers.length; i++) {
            const user = await client.users.fetch(topUsers[i].user_id).catch(() => null);
            if (!user) continue;

            const medals = ['🥇', '🥈', '🥉'];
            const medal = medals[i] || `**${i + 1}.**`;
            const total = topUsers[i].coins + topUsers[i].bank;

            description += `${medal} ${user.tag} - **${total.toLocaleString()}** coins\n`;
        }

        const embed = new EmbedBuilder()
            .setTitle('💰 Richest Users')
            .setDescription(description)
            .setColor('#FFD700')
            .setFooter({ text: message.guild.name })
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
