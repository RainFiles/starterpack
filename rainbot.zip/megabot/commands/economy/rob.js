const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'rob',
    aliases: ['steal'],
    description: 'Attempt to rob another user',
    usage: '<@user>',
    cooldown: 7200,
    async execute(message, args, client) {
        const target = message.mentions.users.first();
        
        if (!target) {
            return message.reply('❌ Please mention a user to rob!');
        }

        if (target.id === message.author.id) {
            return message.reply('❌ You cannot rob yourself!');
        }

        if (target.bot) {
            return message.reply('❌ You cannot rob bots!');
        }

        const robberData = client.db.getUser(message.author.id, message.guild.id);
        const targetData = client.db.getUser(target.id, message.guild.id);

        if (robberData.coins < 500) {
            return message.reply('❌ You need at least 500 coins to attempt a robbery!');
        }

        if (targetData.coins < 1000) {
            return message.reply('❌ Target doesn\'t have enough coins to rob!');
        }

        const success = Math.random() < 0.4; // 40% success rate

        if (success) {
            const stolen = Math.floor(targetData.coins * (Math.random() * 0.3 + 0.1)); // 10-40%
            
            client.db.updateUser(message.author.id, message.guild.id, {
                coins: robberData.coins + stolen
            });
            
            client.db.updateUser(target.id, message.guild.id, {
                coins: targetData.coins - stolen
            });

            const embed = new EmbedBuilder()
                .setTitle('💰 Robbery Successful!')
                .setDescription(`You successfully robbed **${stolen.toLocaleString()}** coins from ${target}!`)
                .setColor('#00FF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } else {
            const fine = Math.floor(robberData.coins * 0.2);
            
            client.db.updateUser(message.author.id, message.guild.id, {
                coins: robberData.coins - fine
            });

            const embed = new EmbedBuilder()
                .setTitle('🚔 Robbery Failed!')
                .setDescription(`You got caught! You paid a fine of **${fine.toLocaleString()}** coins.`)
                .setColor('#FF0000')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        }
    }
};
