const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'work',
    aliases: ['job'],
    description: 'Work to earn coins',
    cooldown: 3600, // 1 hour
    async execute(message, args, client) {
        const userData = client.db.getUser(message.author.id, message.guild.id);

        const jobs = [
            { name: 'Software Developer', min: 500, max: 2000 },
            { name: 'Pizza Delivery', min: 100, max: 500 },
            { name: 'Uber Driver', min: 200, max: 800 },
            { name: 'Discord Mod', min: 50, max: 300 },
            { name: 'YouTuber', min: 300, max: 1500 },
            { name: 'Twitch Streamer', min: 250, max: 1200 },
            { name: 'Professional Gamer', min: 400, max: 1800 },
            { name: 'Chef', min: 300, max: 900 },
            { name: 'Teacher', min: 350, max: 1000 },
            { name: 'Doctor', min: 800, max: 2500 }
        ];

        const job = jobs[Math.floor(Math.random() * jobs.length)];
        const earned = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min;

        client.db.addCoins(message.author.id, message.guild.id, earned);
        client.db.updateUser(message.author.id, message.guild.id, {
            last_work: new Date().toISOString()
        });

        const embed = new EmbedBuilder()
            .setTitle('💼 Work Complete')
            .setDescription(`You worked as a **${job.name}** and earned **${earned.toLocaleString()}** coins!`)
            .addFields(
                { name: '💰 New Balance', value: `${(userData.coins + earned).toLocaleString()} coins` }
            )
            .setColor('#00FF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
