const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'balance',
    aliases: ['bal', 'money', 'wallet', 'cash', 'coins'],
    description: 'Check your balance or another user\'s balance',
    usage: '[@user]',
    async execute(message, args, client) {
        const target = message.mentions.users.first() || message.author;
        const userData = client.db.getUser(target.id, message.guild.id);

        const embed = new EmbedBuilder()
            .setTitle(`💰 ${target.username}'s Balance`)
            .setThumbnail(target.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: '💵 Wallet', value: `${userData.coins.toLocaleString()} coins`, inline: true },
                { name: '🏦 Bank', value: `${userData.bank.toLocaleString()} coins`, inline: true },
                { name: '💎 Total', value: `${(userData.coins + userData.bank).toLocaleString()} coins`, inline: true }
            )
            .setColor('#FFD700')
            .setFooter({ text: `Level ${userData.level} | ${userData.xp} XP` })
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
