const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'pay',
    aliases: ['give', 'transfer'],
    description: 'Pay coins to another user',
    usage: '<@user> <amount>',
    async execute(message, args, client) {
        const target = message.mentions.users.first();
        
        if (!target) {
            return message.reply('❌ Please mention a user to pay!');
        }

        if (target.id === message.author.id) {
            return message.reply('❌ You cannot pay yourself!');
        }

        if (target.bot) {
            return message.reply('❌ You cannot pay bots!');
        }

        const amount = parseInt(args[1]);
        
        if (isNaN(amount) || amount < 1) {
            return message.reply('❌ Please provide a valid amount!');
        }

        const senderData = client.db.getUser(message.author.id, message.guild.id);

        if (amount > senderData.coins) {
            return message.reply('❌ You don\'t have enough coins!');
        }

        // Transfer coins
        client.db.updateUser(message.author.id, message.guild.id, {
            coins: senderData.coins - amount
        });

        const receiverData = client.db.getUser(target.id, message.guild.id);
        client.db.updateUser(target.id, message.guild.id, {
            coins: receiverData.coins + amount
        });

        const embed = new EmbedBuilder()
            .setTitle('💸 Payment Sent')
            .setDescription(`${message.author} paid **${amount.toLocaleString()}** coins to ${target}`)
            .addFields(
                { name: 'Sender Balance', value: `${(senderData.coins - amount).toLocaleString()} coins`, inline: true },
                { name: 'Receiver Balance', value: `${(receiverData.coins + amount).toLocaleString()} coins`, inline: true }
            )
            .setColor('#00FF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
