const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'blackjack',
    aliases: ['bj', '21'],
    description: 'Play blackjack',
    usage: '<bet>',
    async execute(message, args, client) {
        if (!args[0]) {
            return message.reply('❌ Usage: `!blackjack <bet>`');
        }

        const bet = parseInt(args[0]);
        const userData = client.db.getUser(message.author.id, message.guild.id);

        if (isNaN(bet) || bet < 10) {
            return message.reply('❌ Minimum bet is 10 coins!');
        }

        if (bet > userData.coins) {
            return message.reply('❌ You don\'t have enough coins!');
        }

        const deck = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
        const getCard = () => deck[Math.floor(Math.random() * deck.length)];
        const getValue = (card) => {
            if (card === 'A') return 11;
            if (['J', 'Q', 'K'].includes(card)) return 10;
            return parseInt(card);
        };

        const calculateTotal = (hand) => {
            let total = hand.reduce((sum, card) => sum + getValue(card), 0);
            let aces = hand.filter(card => card === 'A').length;
            
            while (total > 21 && aces > 0) {
                total -= 10;
                aces--;
            }
            return total;
        };

        const playerHand = [getCard(), getCard()];
        const dealerHand = [getCard(), getCard()];

        const updateEmbed = (status = 'playing') => {
            const playerTotal = calculateTotal(playerHand);
            const dealerTotal = calculateTotal(dealerHand);
            const dealerDisplay = status === 'playing' ? `${dealerHand[0]} 🃏` : dealerHand.join(' ');
            const dealerTotalDisplay = status === 'playing' ? '?' : dealerTotal;

            return new EmbedBuilder()
                .setTitle('🃏 Blackjack')
                .addFields(
                    { name: 'Your Hand', value: `${playerHand.join(' ')} = **${playerTotal}**` },
                    { name: 'Dealer Hand', value: `${dealerDisplay} = **${dealerTotalDisplay}**` },
                    { name: 'Bet', value: `${bet} coins` }
                )
                .setColor(status === 'win' ? '#00FF00' : status === 'lose' ? '#FF0000' : '#FFFF00')
                .setTimestamp();
        };

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('bj_hit')
                    .setLabel('Hit')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('bj_stand')
                    .setLabel('Stand')
                    .setStyle(ButtonStyle.Danger)
            );

        const msg = await message.reply({ embeds: [updateEmbed()], components: [row] });

        const collector = msg.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 60000
        });

        collector.on('collect', async interaction => {
            if (interaction.customId === 'bj_hit') {
                playerHand.push(getCard());
                const playerTotal = calculateTotal(playerHand);

                if (playerTotal > 21) {
                    client.db.updateUser(message.author.id, message.guild.id, {
                        coins: userData.coins - bet
                    });

                    await interaction.update({
                        embeds: [updateEmbed('lose').setDescription('💥 Bust! You lose!')],
                        components: []
                    });
                    collector.stop();
                } else {
                    await interaction.update({ embeds: [updateEmbed()] });
                }
            } else if (interaction.customId === 'bj_stand') {
                while (calculateTotal(dealerHand) < 17) {
                    dealerHand.push(getCard());
                }

                const playerTotal = calculateTotal(playerHand);
                const dealerTotal = calculateTotal(dealerHand);

                let result, winAmount;
                if (dealerTotal > 21 || playerTotal > dealerTotal) {
                    result = '🎉 You win!';
                    winAmount = bet;
                } else if (playerTotal < dealerTotal) {
                    result = '😢 You lose!';
                    winAmount = -bet;
                } else {
                    result = '🤝 Push! It\'s a tie!';
                    winAmount = 0;
                }

                client.db.updateUser(message.author.id, message.guild.id, {
                    coins: userData.coins + winAmount
                });

                await interaction.update({
                    embeds: [updateEmbed(winAmount > 0 ? 'win' : winAmount < 0 ? 'lose' : 'tie')
                        .setDescription(result)
                        .addFields({ name: 'Result', value: `${winAmount > 0 ? '+' : ''}${winAmount} coins` })],
                    components: []
                });
                collector.stop();
            }
        });
    }
};
