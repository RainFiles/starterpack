const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'crime',
    description: 'Commit a crime to earn coins',
    cooldown: 3600,
    async execute(message, args, client) {
        const userData = client.db.getUser(message.author.id, message.guild.id);

        const crimes = [
            { name: 'rob a bank', min: 500, max: 3000, chance: 0.5 },
            { name: 'steal a car', min: 300, max: 1500, chance: 0.6 },
            { name: 'pickpocket', min: 100, max: 800, chance: 0.7 },
            { name: 'hack a system', min: 1000, max: 5000, chance: 0.3 }
        ];

        const crime = crimes[Math.floor(Math.random() * crimes.length)];
        const success = Math.random() < crime.chance;

        if (success) {
            const earned = Math.floor(Math.random() * (crime.max - crime.min + 1)) + crime.min;
            
            client.db.addCoins(message.author.id, message.guild.id, earned);

            const embed = new EmbedBuilder()
                .setTitle('😈 Crime Successful!')
                .setDescription(`You successfully managed to ${crime.name} and earned **${earned.toLocaleString()}** coins!`)
                .setColor('#00FF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } else {
            const fine = Math.floor(userData.coins * 0.15);
            
            client.db.updateUser(message.author.id, message.guild.id, {
                coins: userData.coins - fine
            });

            const embed = new EmbedBuilder()
                .setTitle('🚨 Crime Failed!')
                .setDescription(`You tried to ${crime.name} but got caught! Fine: **${fine.toLocaleString()}** coins`)
                .setColor('#FF0000')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        }
    }
};
