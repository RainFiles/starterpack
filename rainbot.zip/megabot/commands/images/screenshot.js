const { AttachmentBuilder } = require('discord.js');

module.exports = {
    name: 'screenshot',
    aliases: ['ss', 'capture'],
    description: 'Take a screenshot of a website',
    usage: '<url>',
    async execute(message, args, client) {
        if (!args[0]) {
            return message.reply('❌ Please provide a URL!\nExample: `!screenshot https://google.com`');
        }

        let url = args[0];
        if (!url.startsWith('http')) {
            url = 'https://' + url;
        }

        const screenshotUrl = `https://api.screenshotmachine.com/?key=demo&url=${encodeURIComponent(url)}&dimension=1024x768`;
        
        await message.reply({
            content: `📸 Screenshot of ${url}`,
            files: [{ attachment: screenshotUrl, name: 'screenshot.png' }]
        });
    }
};
