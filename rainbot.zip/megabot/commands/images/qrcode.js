const { AttachmentBuilder } = require('discord.js');

module.exports = {
    name: 'qrcode',
    aliases: ['qr'],
    description: 'Generate a QR code',
    usage: '<text>',
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Please provide text to encode!\nExample: `!qrcode Hello World`');
        }

        const text = args.join(' ');
        const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(text)}`;
        
        await message.reply({
            content: '📱 QR Code Generated:',
            files: [{ attachment: qrUrl, name: 'qrcode.png' }]
        });
    }
};
