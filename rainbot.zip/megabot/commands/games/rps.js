const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'rps',
    aliases: ['rockpaperscissors'],
    description: 'Play Rock Paper Scissors',
    async execute(message, args, client) {
        const choices = ['🪨', '📄', '✂️'];
        const choiceNames = { '🪨': 'Rock', '📄': 'Paper', '✂️': 'Scissors' };

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('rps_rock')
                    .setEmoji('🪨')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('rps_paper')
                    .setEmoji('📄')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('rps_scissors')
                    .setEmoji('✂️')
                    .setStyle(ButtonStyle.Primary)
            );

        const embed = new EmbedBuilder()
            .setTitle('🎮 Rock Paper Scissors')
            .setDescription('Choose your move!')
            .setColor('#FF00FF')
            .setTimestamp();

        const msg = await message.reply({ embeds: [embed], components: [row] });

        const collector = msg.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 30000,
            max: 1
        });

        collector.on('collect', async interaction => {
            const userChoice = interaction.customId.replace('rps_', '');
            const userEmoji = userChoice === 'rock' ? '🪨' : userChoice === 'paper' ? '📄' : '✂️';
            const botEmoji = choices[Math.floor(Math.random() * choices.length)];

            let result;
            if (userEmoji === botEmoji) {
                result = "It's a tie!";
            } else if (
                (userEmoji === '🪨' && botEmoji === '✂️') ||
                (userEmoji === '📄' && botEmoji === '🪨') ||
                (userEmoji === '✂️' && botEmoji === '📄')
            ) {
                result = '🎉 You win!';
            } else {
                result = '😢 You lose!';
            }

            const resultEmbed = new EmbedBuilder()
                .setTitle('🎮 Rock Paper Scissors - Result')
                .addFields(
                    { name: 'Your Choice', value: `${userEmoji} ${choiceNames[userEmoji]}`, inline: true },
                    { name: 'Bot Choice', value: `${botEmoji} ${choiceNames[botEmoji]}`, inline: true },
                    { name: 'Result', value: result }
                )
                .setColor(result.includes('win') ? '#00FF00' : result.includes('lose') ? '#FF0000' : '#FFFF00')
                .setTimestamp();

            await interaction.update({ embeds: [resultEmbed], components: [] });
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                msg.edit({ content: '⏰ Game timed out!', components: [] }).catch(() => {});
            }
        });
    }
};
