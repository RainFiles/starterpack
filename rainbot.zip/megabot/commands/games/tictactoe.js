const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'tictactoe',
    aliases: ['ttt', 'xo'],
    description: 'Play Tic Tac Toe',
    usage: '[@user]',
    async execute(message, args, client) {
        const opponent = message.mentions.users.first();
        
        if (!opponent) {
            return message.reply('❌ Please mention someone to play with!');
        }

        if (opponent.bot) {
            return message.reply('❌ You cannot play with bots!');
        }

        if (opponent.id === message.author.id) {
            return message.reply('❌ You cannot play with yourself!');
        }

        const board = ['⬜', '⬜', '⬜', '⬜', '⬜', '⬜', '⬜', '⬜', '⬜'];
        let currentPlayer = message.author.id;
        const players = { [message.author.id]: '❌', [opponent.id]: '⭕' };

        const createBoard = () => {
            const rows = [];
            for (let i = 0; i < 3; i++) {
                const row = new ActionRowBuilder();
                for (let j = 0; j < 3; j++) {
                    const index = i * 3 + j;
                    row.addComponents(
                        new ButtonBuilder()
                            .setCustomId(`ttt_${index}`)
                            .setEmoji(board[index])
                            .setStyle(ButtonStyle.Secondary)
                            .setDisabled(board[index] !== '⬜')
                    );
                }
                rows.push(row);
            }
            return rows;
        };

        const checkWin = () => {
            const wins = [
                [0, 1, 2], [3, 4, 5], [6, 7, 8],
                [0, 3, 6], [1, 4, 7], [2, 5, 8],
                [0, 4, 8], [2, 4, 6]
            ];

            for (const [a, b, c] of wins) {
                if (board[a] !== '⬜' && board[a] === board[b] && board[a] === board[c]) {
                    return board[a];
                }
            }
            return null;
        };

        const embed = new EmbedBuilder()
            .setTitle('⭕ Tic Tac Toe ❌')
            .setDescription(`${message.author} (❌) vs ${opponent} (⭕)\n\n**Current Turn:** <@${currentPlayer}>`)
            .setColor('#FF00FF')
            .setTimestamp();

        const msg = await message.reply({ embeds: [embed], components: createBoard() });

        const collector = msg.createMessageComponentCollector({
            filter: i => [message.author.id, opponent.id].includes(i.user.id),
            time: 300000
        });

        collector.on('collect', async interaction => {
            if (interaction.user.id !== currentPlayer) {
                return interaction.reply({ content: '❌ It\'s not your turn!', ephemeral: true });
            }

            const index = parseInt(interaction.customId.replace('ttt_', ''));
            board[index] = players[currentPlayer];

            const winner = checkWin();
            const isTie = !board.includes('⬜');

            if (winner || isTie) {
                const resultEmbed = new EmbedBuilder()
                    .setTitle('⭕ Tic Tac Toe ❌ - Game Over')
                    .setDescription(
                        winner 
                            ? `🎉 <@${Object.keys(players).find(k => players[k] === winner)}> wins!`
                            : '🤝 It\'s a tie!'
                    )
                    .setColor(winner ? '#00FF00' : '#FFFF00')
                    .setTimestamp();

                await interaction.update({ embeds: [resultEmbed], components: createBoard() });
                collector.stop();
            } else {
                currentPlayer = currentPlayer === message.author.id ? opponent.id : message.author.id;
                
                const gameEmbed = new EmbedBuilder()
                    .setTitle('⭕ Tic Tac Toe ❌')
                    .setDescription(`${message.author} (❌) vs ${opponent} (⭕)\n\n**Current Turn:** <@${currentPlayer}>`)
                    .setColor('#FF00FF')
                    .setTimestamp();

                await interaction.update({ embeds: [gameEmbed], components: createBoard() });
            }
        });

        collector.on('end', () => {
            msg.edit({ components: [] }).catch(() => {});
        });
    }
};
