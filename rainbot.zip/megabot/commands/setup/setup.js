const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'setup',
    description: 'Setup the bot for your server with an interactive wizard',
    permissions: ['Administrator'],
    async execute(message, args, client) {
        const guildData = client.db.getGuild(message.guild.id);

        const embed = new EmbedBuilder()
            .setTitle('🛠️ Server Setup Wizard')
            .setDescription('Welcome to the Ultimate MegaBot setup! Click the buttons below to configure different features.')
            .setColor('#FF00FF')
            .addFields(
                { name: '🎫 Tickets', value: 'Setup ticket system with custom categories', inline: true },
                { name: '📝 Logging', value: 'Configure logging channels', inline: true },
                { name: '👋 Welcome/Goodbye', value: 'Setup welcome and goodbye messages', inline: true },
                { name: '🎭 Auto Roles', value: 'Configure automatic roles', inline: true },
                { name: '📊 Leveling', value: 'Setup XP and leveling system', inline: true },
                { name: '🛡️ Auto Moderation', value: 'Configure auto-mod rules', inline: true },
                { name: '⭐ Starboard', value: 'Setup starboard feature', inline: true },
                { name: '🎮 Economy', value: 'Configure economy settings', inline: true },
                { name: '⚙️ General', value: 'Prefix and other settings', inline: true }
            )
            .setFooter({ text: `Setup for ${message.guild.name}` })
            .setTimestamp();

        const row1 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('setup_tickets')
                    .setLabel('🎫 Tickets')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('setup_logging')
                    .setLabel('📝 Logging')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('setup_welcome')
                    .setLabel('👋 Welcome')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('setup_autorole')
                    .setLabel('🎭 Auto Role')
                    .setStyle(ButtonStyle.Primary)
            );

        const row2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('setup_leveling')
                    .setLabel('📊 Leveling')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('setup_automod')
                    .setLabel('🛡️ Auto Mod')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('setup_starboard')
                    .setLabel('⭐ Starboard')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('setup_economy')
                    .setLabel('🎮 Economy')
                    .setStyle(ButtonStyle.Primary)
            );

        const row3 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('setup_general')
                    .setLabel('⚙️ General')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('setup_finish')
                    .setLabel('✅ Finish Setup')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('setup_cancel')
                    .setLabel('❌ Cancel')
                    .setStyle(ButtonStyle.Danger)
            );

        const msg = await message.reply({
            embeds: [embed],
            components: [row1, row2, row3]
        });

        const collector = msg.createMessageComponentCollector({ 
            filter: i => i.user.id === message.author.id,
            time: 300000 
        });

        collector.on('collect', async interaction => {
            await interaction.deferUpdate();

            switch(interaction.customId) {
                case 'setup_tickets':
                    await setupTickets(message, interaction, client);
                    break;
                case 'setup_logging':
                    await setupLogging(message, interaction, client);
                    break;
                case 'setup_welcome':
                    await setupWelcome(message, interaction, client);
                    break;
                case 'setup_autorole':
                    await setupAutoRole(message, interaction, client);
                    break;
                case 'setup_leveling':
                    await setupLeveling(message, interaction, client);
                    break;
                case 'setup_automod':
                    await setupAutoMod(message, interaction, client);
                    break;
                case 'setup_starboard':
                    await setupStarboard(message, interaction, client);
                    break;
                case 'setup_economy':
                    await setupEconomy(message, interaction, client);
                    break;
                case 'setup_general':
                    await setupGeneral(message, interaction, client);
                    break;
                case 'setup_finish':
                    client.db.updateGuild(message.guild.id, { setup_complete: 1 });
                    await interaction.editReply({
                        embeds: [{
                            title: '✅ Setup Complete!',
                            description: 'Your server has been configured successfully! Use `!help` to see all available commands.',
                            color: 0x00FF00
                        }],
                        components: []
                    });
                    collector.stop();
                    break;
                case 'setup_cancel':
                    await interaction.editReply({
                        embeds: [{
                            title: '❌ Setup Cancelled',
                            description: 'Setup has been cancelled. You can run `!setup` again anytime.',
                            color: 0xFF0000
                        }],
                        components: []
                    });
                    collector.stop();
                    break;
            }
        });

        collector.on('end', () => {
            msg.edit({ components: [] }).catch(() => {});
        });
    }
};

async function setupTickets(message, interaction, client) {
    const embed = new EmbedBuilder()
        .setTitle('🎫 Ticket System Setup')
        .setDescription('Please provide the following information to setup the ticket system.')
        .setColor('#FF00FF')
        .addFields(
            { name: '1️⃣ Ticket Category', value: 'Which category should tickets be created in?' },
            { name: '2️⃣ Ticket Channel', value: 'Where should the ticket panel be posted?' }
        );

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('ticket_setup_category')
                .setLabel('Set Category')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('ticket_setup_panel')
                .setLabel('Create Panel')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('ticket_add_category')
                .setLabel('Add Category')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('back_to_setup')
                .setLabel('⬅️ Back')
                .setStyle(ButtonStyle.Danger)
        );

    await interaction.editReply({
        embeds: [embed],
        components: [row]
    });
}

async function setupLogging(message, interaction, client) {
    const embed = new EmbedBuilder()
        .setTitle('📝 Logging Setup')
        .setDescription('Configure logging channels for different events.')
        .setColor('#FF00FF')
        .addFields(
            { name: '📋 General Log', value: 'All general events', inline: true },
            { name: '🛡️ Mod Log', value: 'Moderation actions', inline: true },
            { name: '👥 Join/Leave', value: 'Member joins/leaves', inline: true },
            { name: '💬 Message Log', value: 'Deleted/edited messages', inline: true },
            { name: '🔊 Voice Log', value: 'Voice channel events', inline: true }
        );

    await interaction.editReply({
        content: 'Please mention the channels you want to use for logging, or type "skip" to skip this step.',
        embeds: [embed],
        components: []
    });
}

async function setupWelcome(message, interaction, client) {
    const embed = new EmbedBuilder()
        .setTitle('👋 Welcome/Goodbye Setup')
        .setDescription('Configure welcome and goodbye messages for new members.')
        .setColor('#FF00FF')
        .addFields(
            { name: 'Welcome Channel', value: 'Channel for welcome messages' },
            { name: 'Welcome Message', value: 'Use {user}, {server}, {count} as placeholders' },
            { name: 'Goodbye Channel', value: 'Channel for goodbye messages' },
            { name: 'Goodbye Message', value: 'Farewell message template' }
        );

    await interaction.editReply({
        content: 'Please provide the welcome channel ID, or type "skip" to skip.',
        embeds: [embed],
        components: []
    });
}

async function setupAutoRole(message, interaction, client) {
    const embed = new EmbedBuilder()
        .setTitle('🎭 Auto Role Setup')
        .setDescription('Automatically assign roles when members join.')
        .setColor('#FF00FF')
        .addFields(
            { name: 'Auto Role', value: 'Role to assign to new members automatically' }
        );

    await interaction.editReply({
        content: 'Please mention the role or provide the role ID for auto-assignment.',
        embeds: [embed],
        components: []
    });
}

async function setupLeveling(message, interaction, client) {
    const embed = new EmbedBuilder()
        .setTitle('📊 Leveling System Setup')
        .setDescription('Configure the XP and leveling system.')
        .setColor('#FF00FF')
        .addFields(
            { name: 'Enable Leveling', value: 'Turn on/off the leveling system' },
            { name: 'Level Up Channel', value: 'Where to announce level ups' },
            { name: 'Level Up Message', value: 'Custom level up message' }
        );

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('leveling_enable')
                .setLabel('Enable Leveling')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('leveling_disable')
                .setLabel('Disable Leveling')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('back_to_setup')
                .setLabel('⬅️ Back')
                .setStyle(ButtonStyle.Secondary)
        );

    await interaction.editReply({
        embeds: [embed],
        components: [row]
    });
}

async function setupAutoMod(message, interaction, client) {
    const embed = new EmbedBuilder()
        .setTitle('🛡️ Auto Moderation Setup')
        .setDescription('Configure automatic moderation rules.')
        .setColor('#FF00FF')
        .addFields(
            { name: 'Anti-Spam', value: 'Prevent spam messages' },
            { name: 'Anti-Link', value: 'Block unauthorized links' },
            { name: 'Anti-Invite', value: 'Block Discord invites' },
            { name: 'Bad Words Filter', value: 'Filter inappropriate words' }
        );

    await interaction.editReply({
        embeds: [embed],
        components: []
    });
}

async function setupStarboard(message, interaction, client) {
    const embed = new EmbedBuilder()
        .setTitle('⭐ Starboard Setup')
        .setDescription('Highlight popular messages with stars!')
        .setColor('#FF00FF')
        .addFields(
            { name: 'Starboard Channel', value: 'Channel for starred messages' },
            { name: 'Star Threshold', value: 'Number of stars needed (default: 3)' }
        );

    await interaction.editReply({
        embeds: [embed],
        components: []
    });
}

async function setupEconomy(message, interaction, client) {
    const embed = new EmbedBuilder()
        .setTitle('🎮 Economy Setup')
        .setDescription('Configure the economy system.')
        .setColor('#FF00FF')
        .addFields(
            { name: 'Currency Name', value: 'Custom currency name' },
            { name: 'Starting Balance', value: 'Initial coins for new users' },
            { name: 'Daily Reward', value: 'Daily claim amount' }
        );

    await interaction.editReply({
        embeds: [embed],
        components: []
    });
}

async function setupGeneral(message, interaction, client) {
    const embed = new EmbedBuilder()
        .setTitle('⚙️ General Settings')
        .setDescription('Configure general bot settings.')
        .setColor('#FF00FF')
        .addFields(
            { name: 'Prefix', value: `Current: \`${client.db.getGuild(message.guild.id).prefix}\`` },
            { name: 'Language', value: 'Bot language (default: English)' }
        );

    await interaction.editReply({
        embeds: [embed],
        components: []
    });
}
