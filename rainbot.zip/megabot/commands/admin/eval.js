const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'eval',
    description: 'Evaluate JavaScript code (Owner only)',
    ownerOnly: true,
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Please provide code to evaluate!');
        }

        const code = args.join(' ');

        try {
            let evaled = eval(code);
            
            if (typeof evaled !== 'string') {
                evaled = require('util').inspect(evaled);
            }

            if (evaled.length > 1990) {
                evaled = evaled.substring(0, 1990) + '...';
            }

            const embed = new EmbedBuilder()
                .setTitle('✅ Eval Success')
                .addFields(
                    { name: 'Input', value: `\`\`\`js\n${code}\n\`\`\`` },
                    { name: 'Output', value: `\`\`\`js\n${evaled}\n\`\`\`` }
                )
                .setColor('#00FF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            const embed = new EmbedBuilder()
                .setTitle('❌ Eval Error')
                .addFields(
                    { name: 'Input', value: `\`\`\`js\n${code}\n\`\`\`` },
                    { name: 'Error', value: `\`\`\`\n${error.message}\n\`\`\`` }
                )
                .setColor('#FF0000')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        }
    }
};
