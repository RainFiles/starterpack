const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'greroll',
    aliases: ['giveawayreroll', 'reroll'],
    description: 'Reroll a giveaway winner',
    usage: '<message_id>',
    permissions: ['ManageGuild'],
    async execute(message, args, client) {
        if (!args[0]) {
            return message.reply('❌ Please provide a giveaway message ID!');
        }

        const giveaway = client.db.db.prepare(`
            SELECT * FROM giveaways 
            WHERE message_id = ? AND guild_id = ? AND ended = 1
        `).get(args[0], message.guild.id);

        if (!giveaway) {
            return message.reply('❌ No ended giveaway found with that message ID!');
        }

        try {
            const channel = await client.channels.fetch(giveaway.channel_id);
            const giveawayMsg = await channel.messages.fetch(giveaway.message_id);
            
            const reaction = giveawayMsg.reactions.cache.get('🎉');
            if (reaction) {
                const users = await reaction.users.fetch();
                const validUsers = users.filter(u => !u.bot);
                
                if (validUsers.size > 0) {
                    const winnerArray = validUsers.random(Math.min(giveaway.winners, validUsers.size));
                    const winners = Array.isArray(winnerArray) ? winnerArray : [winnerArray];
                    
                    await channel.send(`🎉 **Giveaway Rerolled!**\n\nNew Winner(s): ${winners.map(w => `<@${w.id}>`).join(', ')}\nPrize: **${giveaway.prize}**`);
                    
                    await message.reply('✅ Giveaway rerolled successfully!');
                } else {
                    await message.reply('❌ No valid participants to reroll!');
                }
            }
        } catch (error) {
            console.error('Error rerolling giveaway:', error);
            return message.reply('❌ Failed to reroll giveaway. Please try again.');
        }
    }
};
