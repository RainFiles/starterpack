const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'gend',
    aliases: ['giveawayend', 'endgiveaway'],
    description: 'End a giveaway early',
    usage: '<message_id>',
    permissions: ['ManageGuild'],
    async execute(message, args, client) {
        if (!args[0]) {
            return message.reply('❌ Please provide a giveaway message ID!');
        }

        const giveaway = client.db.db.prepare(`
            SELECT * FROM giveaways 
            WHERE message_id = ? AND guild_id = ? AND ended = 0
        `).get(args[0], message.guild.id);

        if (!giveaway) {
            return message.reply('❌ No active giveaway found with that message ID!');
        }

        try {
            const channel = await client.channels.fetch(giveaway.channel_id);
            const giveawayMsg = await channel.messages.fetch(giveaway.message_id);
            
            const reaction = giveawayMsg.reactions.cache.get('🎉');
            if (reaction) {
                const users = await reaction.users.fetch();
                const validUsers = users.filter(u => !u.bot);
                
                if (validUsers.size > 0) {
                    const winnerArray = validUsers.random(Math.min(giveaway.winners, validUsers.size));
                    const winners = Array.isArray(winnerArray) ? winnerArray : [winnerArray];
                    
                    await channel.send(`🎉 **Giveaway Ended!**\n\nWinner(s): ${winners.map(w => `<@${w.id}>`).join(', ')}\nPrize: **${giveaway.prize}**`);
                    
                    await giveawayMsg.edit({
                        embeds: [{
                            title: '🎉 GIVEAWAY ENDED 🎉',
                            description: `Prize: **${giveaway.prize}**\n\nWinner(s):\n${winners.map(w => `<@${w.id}>`).join('\n')}`,
                            color: 0xFF0000,
                            footer: { text: 'Ended' },
                            timestamp: new Date()
                        }]
                    });
                } else {
                    await channel.send('❌ No valid participants for this giveaway!');
                }
            }

            // Update database
            client.db.db.prepare('UPDATE giveaways SET ended = 1 WHERE id = ?').run(giveaway.id);
            
            await message.reply('✅ Giveaway ended successfully!');

        } catch (error) {
            console.error('Error ending giveaway:', error);
            return message.reply('❌ Failed to end giveaway. Please try again.');
        }
    }
};
