const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'giveaway',
    aliases: ['gstart', 'gcreate'],
    description: 'Start a giveaway',
    usage: '<duration> <winners> <prize>',
    permissions: ['ManageGuild'],
    async execute(message, args, client) {
        if (args.length < 3) {
            return message.reply({
                embeds: [{
                    title: '❌ Invalid Usage',
                    description: 'Usage: `!giveaway <duration> <winners> <prize>`\nExample: `!giveaway 1h 1 Discord Nitro`',
                    color: 0xFF0000
                }]
            });
        }

        const duration = ms(args[0]);
        const winners = parseInt(args[1]);
        const prize = args.slice(2).join(' ');

        if (!duration || duration < 1000) {
            return message.reply('❌ Invalid duration! Use format like: 1h, 30m, 1d');
        }

        if (!winners || winners < 1 || winners > 20) {
            return message.reply('❌ Winner count must be between 1 and 20!');
        }

        const endsAt = new Date(Date.now() + duration);
        const endsAtTimestamp = Math.floor(endsAt.getTime() / 1000);

        const embed = new EmbedBuilder()
            .setTitle('🎉 GIVEAWAY 🎉')
            .setDescription(`Prize: **${prize}**\n\nReact with 🎉 to enter!\nEnds: <t:${endsAtTimestamp}:R>`)
            .addFields(
                { name: 'Hosted by', value: message.author.toString(), inline: true },
                { name: 'Winners', value: `${winners}`, inline: true },
                { name: 'Ends at', value: `<t:${endsAtTimestamp}:F>`, inline: true }
            )
            .setColor('#FF00FF')
            .setFooter({ text: `${winners} winner(s)` })
            .setTimestamp(endsAt);

        const giveawayMsg = await message.channel.send({ embeds: [embed] });
        await giveawayMsg.react('🎉');

        // Save to database
        const stmt = client.db.db.prepare(`
            INSERT INTO giveaways (guild_id, channel_id, message_id, prize, winners, host_id, ends_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `);
        stmt.run(
            message.guild.id,
            message.channel.id,
            giveawayMsg.id,
            prize,
            winners,
            message.author.id,
            endsAt.toISOString()
        );

        await message.reply(`✅ Giveaway started for **${prize}**!`);
    }
};
