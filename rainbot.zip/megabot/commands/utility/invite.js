const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'invite',
    aliases: ['inv', 'botinvite'],
    description: 'Get the bot invite link',
    async execute(message, args, client) {
        const inviteLink = `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`;
        
        const embed = new EmbedBuilder()
            .setTitle('📨 Invite Me!')
            .setDescription(`Add ${client.user.username} to your server!`)
            .addFields(
                { name: 'Features', value: '• 500+ Commands\n• Tickets & Moderation\n• Economy & Leveling\n• Games & Fun\n• And much more!' }
            )
            .setColor('#FF00FF')
            .setThumbnail(client.user.displayAvatarURL())
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel('Invite Bot')
                    .setStyle(ButtonStyle.Link)
                    .setURL(inviteLink)
                    .setEmoji('➕'),
                new ButtonBuilder()
                    .setLabel('Support Server')
                    .setStyle(ButtonStyle.Link)
                    .setURL(client.config.supportServer || 'https://discord.gg/support')
                    .setEmoji('💬')
            );

        await message.reply({ embeds: [embed], components: [row] });
    }
};
