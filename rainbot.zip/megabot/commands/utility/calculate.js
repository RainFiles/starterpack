const { EmbedBuilder } = require('discord.js');
const math = require('mathjs');

module.exports = {
    name: 'calculate',
    aliases: ['calc', 'math'],
    description: 'Calculate a mathematical expression',
    usage: '<expression>',
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Please provide a mathematical expression!\nExample: `!calc 2 + 2 * 5`');
        }

        const expression = args.join(' ');

        try {
            const result = math.evaluate(expression);

            const embed = new EmbedBuilder()
                .setTitle('🔢 Calculator')
                .addFields(
                    { name: 'Expression', value: `\`${expression}\`` },
                    { name: 'Result', value: `\`${result}\`` }
                )
                .setColor('#00FF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            return message.reply('❌ Invalid mathematical expression!');
        }
    }
};
