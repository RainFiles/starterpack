const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'enlarge',
    aliases: ['bigemoji', 'jumbo'],
    description: 'Enlarge an emoji',
    usage: '<emoji>',
    async execute(message, args, client) {
        if (!args[0]) {
            return message.reply('❌ Please provide an emoji!');
        }

        const emoji = args[0].match(/<a?:\w+:(\d+)>/);
        
        if (emoji) {
            const id = emoji[1];
            const isAnimated = args[0].startsWith('<a:');
            const ext = isAnimated ? 'gif' : 'png';
            const url = `https://cdn.discordapp.com/emojis/${id}.${ext}`;
            
            await message.reply({
                files: [{ attachment: url, name: `emoji.${ext}` }]
            });
        } else {
            return message.reply('❌ Please provide a valid custom emoji!');
        }
    }
};
