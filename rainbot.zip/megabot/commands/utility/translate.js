const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'translate',
    aliases: ['tr'],
    description: 'Translate text to another language',
    usage: '<language> <text>',
    async execute(message, args, client) {
        if (args.length < 2) {
            return message.reply('❌ Usage: `!translate <language> <text>`\nExample: `!translate es Hello world`');
        }

        const targetLang = args[0];
        const text = args.slice(1).join(' ');

        try {
            const translate = require('translate-google');
            const result = await translate(text, { to: targetLang });

            const embed = new EmbedBuilder()
                .setTitle('🌐 Translation')
                .addFields(
                    { name: 'Original', value: text },
                    { name: `Translated (${targetLang})`, value: result }
                )
                .setColor('#00FF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            return message.reply('❌ Failed to translate! Check the language code.\nExamples: en, es, fr, de, ja, zh');
        }
    }
};
