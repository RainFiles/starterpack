const { EmbedBuilder } = require('discord.js');
const weather = require('weather-js');

module.exports = {
    name: 'weather',
    aliases: ['forecast'],
    description: 'Get weather information for a location',
    usage: '<location>',
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Please provide a location!\nExample: `!weather London`');
        }

        const location = args.join(' ');

        weather.find({ search: location, degreeType: 'C' }, (err, result) => {
            if (err || !result || result.length === 0) {
                return message.reply('❌ Location not found!');
            }

            const current = result[0].current;
            const location = result[0].location;

            const embed = new EmbedBuilder()
                .setTitle(`🌤️ Weather - ${location.name}`)
                .setDescription(`**${current.skytext}**`)
                .addFields(
                    { name: '🌡️ Temperature', value: `${current.temperature}°C`, inline: true },
                    { name: '🌡️ Feels Like', value: `${current.feelslike}°C`, inline: true },
                    { name: '💨 Wind', value: current.winddisplay, inline: true },
                    { name: '💧 Humidity', value: `${current.humidity}%`, inline: true },
                    { name: '📅 Day', value: current.day, inline: true },
                    { name: '📍 Location', value: `${location.name}, ${location.country}`, inline: true }
                )
                .setThumbnail(current.imageUrl)
                .setColor('#00BFFF')
                .setTimestamp();

            message.reply({ embeds: [embed] });
        });
    }
};
