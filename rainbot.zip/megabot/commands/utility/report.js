const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'report',
    description: 'Report a user or bug',
    usage: '<@user|bug> <reason>',
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Usage: `!report @user <reason>` or `!report bug <description>`');
        }

        const target = message.mentions.users.first();
        const reason = target ? args.slice(1).join(' ') : args.join(' ');

        if (!reason) {
            return message.reply('❌ Please provide a reason/description!');
        }

        const embed = new EmbedBuilder()
            .setTitle('📢 Report Submitted')
            .setDescription(target ? `**User Report**: ${target}` : '**Bug Report**')
            .addFields(
                { name: 'Reported By', value: message.author.tag },
                { name: 'Details', value: reason }
            )
            .setColor('#FF0000')
            .setTimestamp();

        await message.reply({ 
            content: '✅ Your report has been submitted!',
            ephemeral: true 
        });

        // Log to mod channel if available
        const guildData = client.db.getGuild(message.guild.id);
        if (guildData.mod_log_channel) {
            const logChannel = message.guild.channels.cache.get(guildData.mod_log_channel);
            if (logChannel) {
                await logChannel.send({ embeds: [embed] });
            }
        }
    }
};
