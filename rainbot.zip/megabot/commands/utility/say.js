const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'say',
    aliases: ['echo'],
    description: 'Make the bot say something',
    usage: '<message>',
    permissions: ['ManageMessages'],
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Please provide a message!');
        }

        const text = args.join(' ');
        await message.delete().catch(() => {});
        await message.channel.send(text);
    }
};
