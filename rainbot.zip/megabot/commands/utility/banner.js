const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'banner',
    description: 'Get a user\'s banner',
    usage: '[@user]',
    async execute(message, args, client) {
        const target = message.mentions.users.first() || message.author;
        const user = await client.users.fetch(target.id, { force: true });

        if (!user.banner) {
            return message.reply('❌ This user doesn\'t have a banner!');
        }

        const embed = new EmbedBuilder()
            .setTitle(`${user.username}'s Banner`)
            .setImage(user.bannerURL({ size: 1024 }))
            .setColor('#FF00FF')
            .setFooter({ text: `Requested by ${message.author.tag}` })
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
