const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'suggest',
    aliases: ['suggestion'],
    description: 'Make a suggestion',
    usage: '<suggestion>',
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Please provide a suggestion!');
        }

        const suggestion = args.join(' ');

        // Save to database
        const stmt = client.db.db.prepare(`
            INSERT INTO suggestions (guild_id, channel_id, user_id, suggestion)
            VALUES (?, ?, ?, ?)
        `);
        const result = stmt.run(message.guild.id, message.channel.id, message.author.id, suggestion);

        const embed = new EmbedBuilder()
            .setTitle('💡 New Suggestion')
            .setDescription(suggestion)
            .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
            .setColor('#FFFF00')
            .setFooter({ text: `Suggestion #${result.lastInsertRowid}` })
            .setTimestamp();

        const suggestionMsg = await message.channel.send({ embeds: [embed] });
        
        // Add reactions
        await suggestionMsg.react('👍');
        await suggestionMsg.react('👎');

        // Update database with message ID
        const updateStmt = client.db.db.prepare('UPDATE suggestions SET message_id = ? WHERE id = ?');
        updateStmt.run(suggestionMsg.id, result.lastInsertRowid);

        await message.delete().catch(() => {});
    }
};
