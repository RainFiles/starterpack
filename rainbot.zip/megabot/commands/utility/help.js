const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'help',
    aliases: ['h', 'commands', 'cmds'],
    description: 'View all bot commands',
    usage: '[command]',
    async execute(message, args, client) {
        if (args[0]) {
            return showCommandHelp(message, args[0], client);
        }

        const categories = Array.from(client.categories.keys());
        const guildData = client.db.getGuild(message.guild.id);
        const prefix = guildData.prefix || client.config.prefix;

        const embed = new EmbedBuilder()
            .setTitle('📚 Ultimate MegaBot - Command List')
            .setDescription(`Use \`${prefix}help <command>\` for detailed info about a command!\n\nSelect a category below to view commands:`)
            .setColor('#FF00FF')
            .setThumbnail(client.user.displayAvatarURL())
            .addFields(
                { name: '📊 Statistics', value: `\`\`\`Total Commands: ${client.commands.size}\nCategories: ${categories.length}\nPrefix: ${prefix}\`\`\`` }
            )
            .setFooter({ text: `Requested by ${message.author.tag}` })
            .setTimestamp();

        // Add category overview
        const categoryEmojis = {
            setup: '🛠️',
            tickets: '🎫',
            moderation: '🛡️',
            admin: '👑',
            utility: '🔧',
            fun: '🎮',
            economy: '💰',
            leveling: '📊',
            music: '🎵',
            games: '🎲',
            social: '👥',
            vps: '💻',
            server: '🏠',
            roles: '🎭',
            logging: '📝',
            automation: '🤖'
        };

        let categoryList = '';
        categories.forEach(cat => {
            const emoji = categoryEmojis[cat] || '📁';
            const cmdCount = client.categories.get(cat).length;
            categoryList += `${emoji} **${capitalize(cat)}** - ${cmdCount} commands\n`;
        });

        embed.addFields({ name: '📂 Categories', value: categoryList || 'No categories' });

        // Create select menu
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('help_category')
            .setPlaceholder('Select a category')
            .addOptions(
                categories.map(cat => ({
                    label: capitalize(cat),
                    value: cat,
                    description: `View ${client.categories.get(cat).length} ${cat} commands`,
                    emoji: categoryEmojis[cat] || '📁'
                }))
            );

        const row = new ActionRowBuilder().addComponents(selectMenu);

        const buttonRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel('Support Server')
                    .setStyle(ButtonStyle.Link)
                    .setURL(client.config.supportServer || 'https://discord.gg/support')
                    .setEmoji('💬'),
                new ButtonBuilder()
                    .setLabel('Invite Bot')
                    .setStyle(ButtonStyle.Link)
                    .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`)
                    .setEmoji('➕'),
                new ButtonBuilder()
                    .setLabel('Vote')
                    .setStyle(ButtonStyle.Link)
                    .setURL(client.config.voteLink || 'https://top.gg/')
                    .setEmoji('⬆️')
            );

        const msg = await message.reply({
            embeds: [embed],
            components: [row, buttonRow]
        });

        const collector = msg.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 120000
        });

        collector.on('collect', async interaction => {
            if (interaction.customId === 'help_category') {
                await interaction.deferUpdate();
                const category = interaction.values[0];
                await showCategory(interaction, category, client, prefix);
            }
        });

        collector.on('end', () => {
            msg.edit({ components: [] }).catch(() => {});
        });
    }
};

async function showCategory(interaction, category, client, prefix) {
    const commands = client.categories.get(category);
    
    const embed = new EmbedBuilder()
        .setTitle(`📂 ${capitalize(category)} Commands`)
        .setDescription(`All commands in the **${category}** category:`)
        .setColor('#FF00FF')
        .setTimestamp();

    let cmdList = '';
    commands.forEach(cmd => {
        const aliases = cmd.aliases ? ` (${cmd.aliases.join(', ')})` : '';
        cmdList += `\`${prefix}${cmd.name}\`${aliases} - ${cmd.description || 'No description'}\n`;
    });

    embed.addFields({ name: `Commands (${commands.length})`, value: cmdList || 'No commands' });

    await interaction.editReply({ embeds: [embed] });
}

async function showCommandHelp(message, commandName, client) {
    const command = client.commands.get(commandName) || 
                   client.commands.get(client.aliases.get(commandName));

    if (!command) {
        return message.reply({
            embeds: [{
                title: '❌ Command Not Found',
                description: `Command \`${commandName}\` doesn't exist!`,
                color: 0xFF0000
            }]
        });
    }

    const guildData = client.db.getGuild(message.guild.id);
    const prefix = guildData.prefix || client.config.prefix;

    const embed = new EmbedBuilder()
        .setTitle(`📖 Command: ${command.name}`)
        .setDescription(command.description || 'No description provided')
        .addFields(
            { name: 'Usage', value: `\`${prefix}${command.name} ${command.usage || ''}\``, inline: true },
            { name: 'Aliases', value: command.aliases ? command.aliases.map(a => `\`${a}\``).join(', ') : 'None', inline: true },
            { name: 'Cooldown', value: command.cooldown ? `${command.cooldown} seconds` : 'None', inline: true }
        )
        .setColor('#FF00FF')
        .setTimestamp();

    if (command.permissions) {
        embed.addFields({ name: 'Required Permissions', value: command.permissions.join(', ') });
    }

    await message.reply({ embeds: [embed] });
}

function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}
