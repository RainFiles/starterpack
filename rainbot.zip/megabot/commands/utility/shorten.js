const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'shorten',
    aliases: ['shorturl', 'tinyurl'],
    description: 'Shorten a URL',
    usage: '<url>',
    async execute(message, args, client) {
        if (!args[0]) {
            return message.reply('❌ Please provide a URL to shorten!');
        }

        try {
            const { data } = await axios.get(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(args[0])}`);
            
            const embed = new EmbedBuilder()
                .setTitle('🔗 URL Shortened')
                .addFields(
                    { name: 'Original', value: args[0] },
                    { name: 'Shortened', value: data }
                )
                .setColor('#00FF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            return message.reply('❌ Failed to shorten URL!');
        }
    }
};
