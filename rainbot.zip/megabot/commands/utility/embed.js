const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'embed',
    description: 'Create an embed message',
    usage: '<title> | <description>',
    permissions: ['ManageMessages'],
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Usage: `!embed <title> | <description>`');
        }

        const parts = args.join(' ').split('|');
        const title = parts[0]?.trim() || 'Embed';
        const description = parts[1]?.trim() || 'No description';

        const embed = new EmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor('#FF00FF')
            .setTimestamp();

        await message.channel.send({ embeds: [embed] });
        await message.delete().catch(() => {});
    }
};
