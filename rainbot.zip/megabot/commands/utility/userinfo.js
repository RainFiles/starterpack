const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'userinfo',
    aliases: ['ui', 'whois', 'user', 'memberinfo'],
    description: 'Display user information',
    usage: '[@user]',
    async execute(message, args, client) {
        const target = message.mentions.members.first() || message.member;
        const user = target.user;
        
        const createdAt = Math.floor(user.createdTimestamp / 1000);
        const joinedAt = Math.floor(target.joinedTimestamp / 1000);

        const roles = target.roles.cache
            .sort((a, b) => b.position - a.position)
            .map(role => role)
            .slice(0, -1);

        const embed = new EmbedBuilder()
            .setTitle(`👤 ${user.tag}`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 512 }))
            .addFields(
                { name: '🆔 ID', value: user.id, inline: true },
                { name: '📛 Nickname', value: target.nickname || 'None', inline: true },
                { name: '🤖 Bot', value: user.bot ? 'Yes' : 'No', inline: true },
                { name: '📅 Account Created', value: `<t:${createdAt}:R>`, inline: true },
                { name: '📥 Joined Server', value: `<t:${joinedAt}:R>`, inline: true },
                { name: '🎭 Roles', value: roles.length > 0 ? roles.join(', ') : 'None' }
            )
            .setColor(target.displayHexColor || '#FF00FF')
            .setFooter({ text: `Requested by ${message.author.tag}` })
            .setTimestamp();

        if (user.banner) {
            embed.setImage(user.bannerURL({ size: 1024 }));
        }

        await message.reply({ embeds: [embed] });
    }
};
