const { EmbedBuilder } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'uptime',
    description: 'Check bot uptime',
    async execute(message, args, client) {
        const uptime = ms(client.uptime, { long: true });

        const embed = new EmbedBuilder()
            .setTitle('⏱️ Bot Uptime')
            .setDescription(`The bot has been online for:\n**${uptime}**`)
            .setColor('#00FF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
