const { EmbedBuilder } = require('discord.js');
const os = require('os');

module.exports = {
    name: 'botstats',
    aliases: ['stats', 'botinfo', 'info'],
    description: 'View bot statistics',
    async execute(message, args, client) {
        const uptime = Math.floor(client.uptime / 1000);
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = uptime % 60;

        const totalMemory = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
        const usedMemory = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

        const embed = new EmbedBuilder()
            .setTitle('📊 Bot Statistics')
            .setThumbnail(client.user.displayAvatarURL())
            .addFields(
                { name: '🏠 Servers', value: `${client.guilds.cache.size}`, inline: true },
                { name: '👥 Users', value: `${client.users.cache.size}`, inline: true },
                { name: '💬 Channels', value: `${client.channels.cache.size}`, inline: true },
                { name: '📝 Commands', value: `${client.commands.size}`, inline: true },
                { name: '🏓 Ping', value: `${Math.round(client.ws.ping)}ms`, inline: true },
                { name: '⏰ Uptime', value: `${days}d ${hours}h ${minutes}m ${seconds}s`, inline: true },
                { name: '💾 Memory', value: `${usedMemory}MB / ${totalMemory}GB`, inline: true },
                { name: '🖥️ CPU', value: `${os.cpus()[0].model}`, inline: true },
                { name: '📌 Node.js', value: process.version, inline: true }
            )
            .setColor('#FF00FF')
            .setFooter({ text: `Bot created by ${client.users.cache.get(client.config.ownerIDs[0])?.tag || 'Unknown'}` })
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
