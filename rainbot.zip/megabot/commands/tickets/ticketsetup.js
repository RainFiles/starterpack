const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    name: 'ticketsetup',
    aliases: ['tsetup', 'ticket-setup'],
    description: 'Setup advanced ticket system with custom categories',
    permissions: ['Administrator'],
    async execute(message, args, client) {
        const embed = new EmbedBuilder()
            .setTitle('🎫 Ticket Setup')
            .setDescription('Please enter the requested information as prompted. This embed will automatically populate with the information you provide.')
            .setColor('#FF00FF')
            .addFields(
                { name: 'Step 1', value: 'Click buttons below to add/customize categories' },
                { name: 'Current Categories', value: 'None' }
            );

        const row1 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('add_green_category')
                    .setLabel('Add Green Button')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('add_gray_category')
                    .setLabel('Add Gray Button')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('add_blue_category')
                    .setLabel('Add Blue Button')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('add_red_category')
                    .setLabel('Add Red Button')
                    .setStyle(ButtonStyle.Danger)
            );

        const row2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_finish')
                    .setLabel('FINISH')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('ticket_remove_category')
                    .setLabel('Remove Category')
                    .setStyle(ButtonStyle.Secondary)
            );

        const msg = await message.reply({
            content: 'Use the buttons below to add categories',
            embeds: [embed],
            components: [row1, row2]
        });

        const categories = [];
        const collector = msg.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 600000
        });

        collector.on('collect', async interaction => {
            if (interaction.customId.startsWith('add_')) {
                const color = interaction.customId.replace('add_', '').replace('_category', '');
                await addCategory(interaction, categories, color, message, client);
            } else if (interaction.customId === 'ticket_remove_category') {
                await removeCategory(interaction, categories);
            } else if (interaction.customId === 'ticket_finish') {
                await finishTicketSetup(interaction, categories, message, client);
                collector.stop();
            } else if (interaction.customId === 'category_title') {
                await interaction.showModal({
                    title: 'Category Title',
                    customId: `modal_title_${Date.now()}`,
                    components: [{
                        type: 1,
                        components: [{
                            type: 4,
                            customId: 'title_input',
                            label: 'Enter category title',
                            style: 1,
                            placeholder: 'e.g., Support',
                            required: true
                        }]
                    }]
                });
            }
        });
    }
};

async function addCategory(interaction, categories, color, message, client) {
    await interaction.deferUpdate();

    // Show modal for category details
    const categoryEmbed = new EmbedBuilder()
        .setTitle('✏️ Category Configuration')
        .setDescription('Enter details for this ticket category')
        .setColor(getColorHex(color))
        .addFields(
            { name: 'Title', value: 'Click "Title" button below', inline: true },
            { name: 'Description', value: 'Click "Description" button below', inline: true },
            { name: 'Color', value: color.toUpperCase(), inline: true },
            { name: 'Image', value: 'Optional image URL', inline: true },
            { name: 'Thumbnail', value: 'Optional thumbnail URL', inline: true },
            { name: 'JSON', value: 'Advanced: Paste embed JSON', inline: true }
        );

    const configRow = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('category_title')
                .setLabel('Title')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('category_description')
                .setLabel('Description')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('category_color')
                .setLabel('Color')
                .setStyle(ButtonStyle.Primary)
        );

    const configRow2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('category_image')
                .setLabel('Image')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('category_thumbnail')
                .setLabel('Thumbnail')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('category_json')
                .setLabel('JSON')
                .setStyle(ButtonStyle.Secondary)
        );

    const saveRow = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('save_category')
                .setLabel('Save & Set Category')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('category_exit')
                .setLabel('Exit')
                .setStyle(ButtonStyle.Danger)
        );

    await interaction.editReply({
        content: null,
        embeds: [categoryEmbed],
        components: [configRow, configRow2, saveRow]
    });

    const category = {
        color: color,
        title: '',
        description: '',
        emoji: getEmojiForColor(color),
        style: getButtonStyle(color)
    };

    categories.push(category);

    // Handle configuration
    const configCollector = interaction.message.createMessageComponentCollector({
        filter: i => i.user.id === message.author.id,
        time: 300000
    });

    configCollector.on('collect', async i => {
        if (i.customId === 'save_category') {
            await i.deferUpdate();
            
            // Save category to database
            const stmt = client.db.db.prepare(`
                INSERT INTO ticket_categories (guild_id, name, emoji, color, description, position)
                VALUES (?, ?, ?, ?, ?, ?)
            `);
            stmt.run(
                message.guild.id,
                category.title || 'Unnamed Category',
                category.emoji,
                category.color,
                category.description || '',
                categories.length - 1
            );

            await i.followUp({
                content: '✅ Category saved successfully!',
                ephemeral: true
            });
            
            configCollector.stop();
        } else if (i.customId === 'category_exit') {
            await i.deferUpdate();
            configCollector.stop();
        }
    });
}

async function removeCategory(interaction, categories) {
    await interaction.deferUpdate();
    
    if (categories.length === 0) {
        return interaction.followUp({
            content: '❌ No categories to remove!',
            ephemeral: true
        });
    }

    categories.pop();
    
    await interaction.followUp({
        content: '✅ Last category removed!',
        ephemeral: true
    });
}

async function finishTicketSetup(interaction, categories, message, client) {
    await interaction.deferUpdate();

    if (categories.length === 0) {
        return interaction.followUp({
            content: '❌ Please add at least one category before finishing!',
            ephemeral: true
        });
    }

    // Ask for ticket channel
    await interaction.followUp({
        content: '📍 Please mention the channel where you want the ticket panel to be posted, or provide the channel ID.',
        ephemeral: false
    });

    const filter = m => m.author.id === message.author.id;
    const collected = await message.channel.awaitMessages({ filter, max: 1, time: 60000 });

    if (!collected.size) {
        return interaction.followUp({
            content: '⏰ Setup timed out. Please run the command again.',
            ephemeral: true
        });
    }

    const channelMsg = collected.first();
    const channelId = channelMsg.content.replace(/[<>#]/g, '');
    const ticketChannel = message.guild.channels.cache.get(channelId);

    if (!ticketChannel) {
        return interaction.followUp({
            content: '❌ Invalid channel! Please run the command again.',
            ephemeral: true
        });
    }

    // Create ticket panel
    const panelEmbed = new EmbedBuilder()
        .setTitle('🎫 Ticket Support')
        .setDescription('Click a button below to create a ticket and get help from our support team!')
        .setColor('#FF00FF')
        .setFooter({ text: message.guild.name })
        .setTimestamp();

    // Create buttons for categories
    const buttons = categories.map((cat, index) => 
        new ButtonBuilder()
            .setCustomId(`ticket_create_${index}`)
            .setLabel(cat.title || `Category ${index + 1}`)
            .setEmoji(cat.emoji)
            .setStyle(cat.style)
    );

    const rows = [];
    for (let i = 0; i < buttons.length; i += 4) {
        const row = new ActionRowBuilder()
            .addComponents(buttons.slice(i, i + 4));
        rows.push(row);
    }

    await ticketChannel.send({
        embeds: [panelEmbed],
        components: rows
    });

    // Save to database
    client.db.updateGuild(message.guild.id, {
        ticket_channel: ticketChannel.id,
        ticket_category: ticketChannel.parentId
    });

    await interaction.followUp({
        content: `✅ Ticket panel created in ${ticketChannel}!`,
        ephemeral: false
    });
}

function getColorHex(color) {
    const colors = {
        green: 0x00FF00,
        gray: 0x808080,
        grey: 0x808080,
        blue: 0x0000FF,
        red: 0xFF0000
    };
    return colors[color.toLowerCase()] || 0xFF00FF;
}

function getEmojiForColor(color) {
    const emojis = {
        green: '✅',
        gray: '⚪',
        grey: '⚪',
        blue: '🔵',
        red: '🔴'
    };
    return emojis[color.toLowerCase()] || '🎫';
}

function getButtonStyle(color) {
    const styles = {
        green: ButtonStyle.Success,
        gray: ButtonStyle.Secondary,
        grey: ButtonStyle.Secondary,
        blue: ButtonStyle.Primary,
        red: ButtonStyle.Danger
    };
    return styles[color.toLowerCase()] || ButtonStyle.Primary;
}
