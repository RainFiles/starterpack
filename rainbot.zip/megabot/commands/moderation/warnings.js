const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'warnings',
    aliases: ['warns', 'infractions'],
    description: 'View warnings for a user',
    usage: '[@user]',
    permissions: ['ModerateMembers'],
    async execute(message, args, client) {
        const target = message.mentions.members.first() || message.member;

        const stmt = client.db.db.prepare(`
            SELECT * FROM warnings 
            WHERE guild_id = ? AND user_id = ?
            ORDER BY created_at DESC
        `);
        const warnings = stmt.all(message.guild.id, target.id);

        if (!warnings.length) {
            return message.reply(`${target} has no warnings!`);
        }

        let description = '';
        warnings.forEach((warn, i) => {
            const date = new Date(warn.created_at).toLocaleDateString();
            description += `**${i + 1}.** ${warn.reason} - *${date}*\n`;
        });

        const embed = new EmbedBuilder()
            .setTitle(`⚠️ Warnings for ${target.user.tag}`)
            .setDescription(description)
            .addFields({ name: 'Total Warnings', value: `${warnings.length}` })
            .setColor('#FFFF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
