const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'unban',
    description: 'Unban a user from the server',
    usage: '<user_id> [reason]',
    permissions: ['BanMembers'],
    botPermissions: ['BanMembers'],
    async execute(message, args, client) {
        if (!args[0]) {
            return message.reply({
                embeds: [{
                    title: '❌ Invalid Usage',
                    description: 'Please provide a user ID!\nUsage: `!unban <user_id> [reason]`',
                    color: 0xFF0000
                }]
            });
        }

        const userId = args[0];
        const reason = args.slice(1).join(' ') || 'No reason provided';

        try {
            const bans = await message.guild.bans.fetch();
            const bannedUser = bans.find(ban => ban.user.id === userId);

            if (!bannedUser) {
                return message.reply({
                    embeds: [{
                        title: '❌ User Not Banned',
                        description: 'This user is not banned from the server!',
                        color: 0xFF0000
                    }]
                });
            }

            await message.guild.bans.remove(userId, reason);

            const embed = new EmbedBuilder()
                .setTitle('✅ User Unbanned')
                .setDescription(`**${bannedUser.user.tag}** has been unbanned`)
                .addFields(
                    { name: 'User ID', value: userId },
                    { name: 'Reason', value: reason },
                    { name: 'Moderator', value: message.author.tag }
                )
                .setColor('#00FF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });

            // Log to database
            const stmt = client.db.db.prepare(`
                INSERT INTO mod_actions (guild_id, user_id, moderator_id, action, reason)
                VALUES (?, ?, ?, 'unban', ?)
            `);
            stmt.run(message.guild.id, userId, message.author.id, reason);

        } catch (error) {
            console.error('Error unbanning user:', error);
            return message.reply({
                embeds: [{
                    title: '❌ Error',
                    description: 'Failed to unban the user. Please check the user ID.',
                    color: 0xFF0000
                }]
            });
        }
    }
};
