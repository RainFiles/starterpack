const { EmbedBuilder } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'timeout',
    aliases: ['tempmute'],
    description: 'Timeout a member for a specified duration',
    usage: '<@user> <duration> [reason]',
    permissions: ['ModerateMembers'],
    botPermissions: ['ModerateMembers'],
    async execute(message, args, client) {
        const member = message.mentions.members.first();
        
        if (!member || !args[1]) {
            return message.reply('❌ Usage: `!timeout @user <duration> [reason]`\nExample: `!timeout @user 10m Spamming`');
        }

        const duration = ms(args[1]);
        const reason = args.slice(2).join(' ') || 'No reason provided';

        if (!duration || duration < 1000 || duration > 28 * 24 * 60 * 60 * 1000) {
            return message.reply('❌ Duration must be between 1 second and 28 days!');
        }

        if (!member.moderatable) {
            return message.reply('❌ I cannot timeout this member!');
        }

        try {
            await member.timeout(duration, reason);

            const embed = new EmbedBuilder()
                .setTitle('⏰ Member Timed Out')
                .setDescription(`${member} has been timed out`)
                .addFields(
                    { name: 'Duration', value: args[1], inline: true },
                    { name: 'Reason', value: reason, inline: true },
                    { name: 'Moderator', value: message.author.tag }
                )
                .setColor('#FF0000')
                .setTimestamp();

            await message.reply({ embeds: [embed] });

            // DM user
            await member.send({
                embeds: [{
                    title: '⏰ You have been timed out',
                    description: `You were timed out in **${message.guild.name}**`,
                    fields: [
                        { name: 'Duration', value: args[1] },
                        { name: 'Reason', value: reason }
                    ],
                    color: 0xFF0000
                }]
            }).catch(() => {});

        } catch (error) {
            console.error('Error timing out member:', error);
            return message.reply('❌ Failed to timeout member!');
        }
    }
};
