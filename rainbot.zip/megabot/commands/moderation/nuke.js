const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'nuke',
    description: 'Delete and recreate a channel (clears all messages)',
    permissions: ['Administrator'],
    botPermissions: ['ManageChannels'],
    async execute(message, args, client) {
        const channel = message.channel;

        const confirmMsg = await message.reply('⚠️ Are you sure you want to nuke this channel? Reply with `yes` to confirm (30s timeout)');

        const filter = m => m.author.id === message.author.id && m.content.toLowerCase() === 'yes';
        const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });

        if (!collected.size) {
            return confirmMsg.edit('❌ Nuke cancelled - timed out.');
        }

        try {
            const position = channel.position;
            const newChannel = await channel.clone();
            await newChannel.setPosition(position);
            await channel.delete();

            const embed = new EmbedBuilder()
                .setTitle('💥 Channel Nuked')
                .setDescription(`Channel nuked by ${message.author}`)
                .setImage('https://media.giphy.com/media/HhTXt43pk1I1W/giphy.gif')
                .setColor('#FF0000')
                .setTimestamp();

            await newChannel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error nuking channel:', error);
            return message.channel.send('❌ Failed to nuke channel!');
        }
    }
};
