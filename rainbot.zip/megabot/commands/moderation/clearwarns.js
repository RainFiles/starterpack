const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'clearwarns',
    aliases: ['clearwarnings', 'removewarns'],
    description: 'Clear all warnings for a user',
    usage: '<@user>',
    permissions: ['Administrator'],
    async execute(message, args, client) {
        const member = message.mentions.members.first();
        
        if (!member) {
            return message.reply('❌ Please mention a user!');
        }

        const stmt = client.db.db.prepare(`
            DELETE FROM warnings 
            WHERE guild_id = ? AND user_id = ?
        `);
        const result = stmt.run(message.guild.id, member.id);

        const embed = new EmbedBuilder()
            .setTitle('✅ Warnings Cleared')
            .setDescription(`Cleared **${result.changes}** warnings for ${member}`)
            .setColor('#00FF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
