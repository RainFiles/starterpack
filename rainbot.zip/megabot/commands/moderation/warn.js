const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'warn',
    description: 'Warn a member',
    usage: '<@user> <reason>',
    permissions: ['ModerateMembers'],
    async execute(message, args, client) {
        const member = message.mentions.members.first();
        
        if (!member) {
            return message.reply('❌ Please mention a user to warn!');
        }

        if (!args[1]) {
            return message.reply('❌ Please provide a reason for the warning!');
        }

        const reason = args.slice(1).join(' ');

        // Add warning to database
        const stmt = client.db.db.prepare(`
            INSERT INTO warnings (guild_id, user_id, moderator_id, reason)
            VALUES (?, ?, ?, ?)
        `);
        stmt.run(message.guild.id, member.id, message.author.id, reason);

        // Get warning count
        const countStmt = client.db.db.prepare(`
            SELECT COUNT(*) as count FROM warnings 
            WHERE guild_id = ? AND user_id = ?
        `);
        const { count } = countStmt.get(message.guild.id, member.id);

        const embed = new EmbedBuilder()
            .setTitle('⚠️ Member Warned')
            .setDescription(`${member} has been warned`)
            .addFields(
                { name: 'Reason', value: reason },
                { name: 'Moderator', value: message.author.tag },
                { name: 'Total Warnings', value: `${count}` }
            )
            .setColor('#FFFF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });

        // DM user
        await member.send({
            embeds: [{
                title: '⚠️ You have been warned',
                description: `You were warned in **${message.guild.name}**`,
                fields: [
                    { name: 'Reason', value: reason },
                    { name: 'Total Warnings', value: `${count}` }
                ],
                color: 0xFFFF00
            }]
        }).catch(() => {});
    }
};
