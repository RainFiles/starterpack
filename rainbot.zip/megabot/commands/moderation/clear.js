const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'clear',
    aliases: ['purge', 'delete', 'clean'],
    description: 'Delete multiple messages at once',
    usage: '<amount> [user/@user]',
    permissions: ['ManageMessages'],
    botPermissions: ['ManageMessages'],
    async execute(message, args, client) {
        if (!args[0]) {
            return message.reply({
                embeds: [{
                    title: '❌ Invalid Usage',
                    description: 'Usage: `!clear <amount> [user/@user]`\nExample: `!clear 100` or `!clear 50 @user`',
                    color: 0xFF0000
                }]
            });
        }

        let amount = parseInt(args[0]);
        
        if (isNaN(amount) || amount < 1 || amount > 100) {
            return message.reply({
                embeds: [{
                    title: '❌ Invalid Amount',
                    description: 'Please provide a number between 1 and 100!',
                    color: 0xFF0000
                }]
            });
        }

        try {
            let deleted = 0;
            let targetUser = null;

            // Check if targeting specific user
            if (args[1]) {
                targetUser = message.mentions.users.first() || 
                           await client.users.fetch(args[1]).catch(() => null);
            }

            // Delete messages
            if (targetUser) {
                const messages = await message.channel.messages.fetch({ limit: 100 });
                const userMessages = messages.filter(m => m.author.id === targetUser.id).first(amount);
                
                for (const msg of userMessages.values()) {
                    await msg.delete().catch(() => {});
                    deleted++;
                    await new Promise(resolve => setTimeout(resolve, 500)); // Rate limit protection
                }
            } else {
                const deletedMessages = await message.channel.bulkDelete(amount, true);
                deleted = deletedMessages.size;
            }

            const embed = new EmbedBuilder()
                .setTitle('🗑️ Messages Cleared')
                .setDescription(`Successfully deleted ${deleted} message(s)${targetUser ? ` from ${targetUser.tag}` : ''}`)
                .setColor('#00FF00')
                .setFooter({ text: `Requested by ${message.author.tag}` })
                .setTimestamp();

            const reply = await message.channel.send({ embeds: [embed] });
            
            // Auto-delete confirmation after 5 seconds
            setTimeout(() => reply.delete().catch(() => {}), 5000);

            // Log action
            const guildData = client.db.getGuild(message.guild.id);
            if (guildData.mod_log_channel) {
                const logChannel = message.guild.channels.cache.get(guildData.mod_log_channel);
                if (logChannel) {
                    await logChannel.send({
                        embeds: [{
                            title: '📝 Messages Cleared',
                            fields: [
                                { name: 'Moderator', value: `${message.author.tag} (${message.author.id})`, inline: true },
                                { name: 'Channel', value: `${message.channel}`, inline: true },
                                { name: 'Amount', value: `${deleted}`, inline: true },
                                { name: 'Target', value: targetUser ? `${targetUser.tag}` : 'All users', inline: true }
                            ],
                            color: 0xFFFF00,
                            timestamp: new Date()
                        }]
                    });
                }
            }

        } catch (error) {
            console.error('Error clearing messages:', error);
            return message.reply({
                embeds: [{
                    title: '❌ Error',
                    description: 'An error occurred while clearing messages. Messages older than 14 days cannot be bulk deleted.',
                    color: 0xFF0000
                }]
            });
        }
    }
};
