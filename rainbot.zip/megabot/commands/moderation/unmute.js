const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'unmute',
    aliases: ['untimeout'],
    description: 'Unmute a member',
    usage: '<@user>',
    permissions: ['ModerateMembers'],
    botPermissions: ['ModerateMembers'],
    async execute(message, args, client) {
        const member = message.mentions.members.first();
        
        if (!member) {
            return message.reply('❌ Please mention a user to unmute!');
        }

        try {
            await member.timeout(null);
            
            const embed = new EmbedBuilder()
                .setTitle('🔊 Member Unmuted')
                .setDescription(`${member} has been unmuted`)
                .addFields({ name: 'Moderator', value: message.author.tag })
                .setColor('#00FF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error unmuting member:', error);
            return message.reply('❌ Failed to unmute member!');
        }
    }
};
