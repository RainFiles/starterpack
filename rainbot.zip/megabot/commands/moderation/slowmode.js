const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'slowmode',
    aliases: ['slow', 'sm'],
    description: 'Set slowmode for a channel',
    usage: '<time> [channel]',
    permissions: ['ManageChannels'],
    botPermissions: ['ManageChannels'],
    async execute(message, args, client) {
        if (!args[0]) {
            return message.reply({
                embeds: [{
                    title: '❌ Invalid Usage',
                    description: 'Usage: `!slowmode <time> [channel]`\nExamples: `!slowmode 5s`, `!slowmode 10m`, `!slowmode off`',
                    color: 0xFF0000
                }]
            });
        }

        const channel = message.mentions.channels.first() || message.channel;
        
        let time = 0;
        if (args[0].toLowerCase() !== 'off' && args[0] !== '0') {
            time = ms(args[0]) / 1000;
            if (!time || time < 0 || time > 21600) {
                return message.reply({
                    embeds: [{
                        title: '❌ Invalid Time',
                        description: 'Please provide a valid time between 0 seconds and 6 hours!\nExamples: `5s`, `1m`, `1h`',
                        color: 0xFF0000
                    }]
                });
            }
        }

        try {
            await channel.setRateLimitPerUser(time);

            const embed = new EmbedBuilder()
                .setTitle('⏱️ Slowmode Updated')
                .setDescription(`Slowmode ${time === 0 ? 'disabled' : `set to ${args[0]}`} in ${channel}`)
                .setColor(time === 0 ? '#00FF00' : '#FFFF00')
                .setFooter({ text: `Set by ${message.author.tag}` })
                .setTimestamp();

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error setting slowmode:', error);
            return message.reply({
                embeds: [{
                    title: '❌ Error',
                    description: 'Failed to set slowmode. Please check my permissions.',
                    color: 0xFF0000
                }]
            });
        }
    }
};
