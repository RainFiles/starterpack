const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'kick',
    description: 'Kick a member from the server',
    usage: '<user> [reason]',
    permissions: ['KickMembers'],
    botPermissions: ['KickMembers'],
    async execute(message, args, client) {
        const member = message.mentions.members.first() || 
                      await message.guild.members.fetch(args[0]).catch(() => null);

        if (!member) {
            return message.reply({
                embeds: [{
                    title: '❌ Invalid User',
                    description: 'Please mention a valid user or provide their ID!',
                    color: 0xFF0000
                }]
            });
        }

        if (member.id === message.author.id) {
            return message.reply('❌ You cannot kick yourself!');
        }

        if (member.id === client.user.id) {
            return message.reply('❌ I cannot kick myself!');
        }

        if (member.roles.highest.position >= message.member.roles.highest.position) {
            return message.reply('❌ You cannot kick this user due to role hierarchy!');
        }

        if (!member.kickable) {
            return message.reply('❌ I cannot kick this user! They may have a higher role than me.');
        }

        const reason = args.slice(1).join(' ') || 'No reason provided';

        try {
            // DM user before kicking
            await member.send({
                embeds: [{
                    title: '👢 You have been kicked',
                    description: `You were kicked from **${message.guild.name}**`,
                    fields: [
                        { name: 'Reason', value: reason },
                        { name: 'Moderator', value: message.author.tag }
                    ],
                    color: 0xFF0000,
                    timestamp: new Date()
                }]
            }).catch(() => {});

            await member.kick(reason);

            const embed = new EmbedBuilder()
                .setTitle('👢 Member Kicked')
                .setDescription(`**${member.user.tag}** has been kicked`)
                .addFields(
                    { name: 'Reason', value: reason },
                    { name: 'Moderator', value: message.author.tag }
                )
                .setColor('#FF0000')
                .setTimestamp();

            await message.reply({ embeds: [embed] });

            // Log to database
            const stmt = client.db.db.prepare(`
                INSERT INTO mod_actions (guild_id, user_id, moderator_id, action, reason)
                VALUES (?, ?, ?, 'kick', ?)
            `);
            stmt.run(message.guild.id, member.id, message.author.id, reason);

            // Log to mod log channel
            const guildData = client.db.getGuild(message.guild.id);
            if (guildData.mod_log_channel) {
                const logChannel = message.guild.channels.cache.get(guildData.mod_log_channel);
                if (logChannel) {
                    await logChannel.send({ embeds: [embed] });
                }
            }

        } catch (error) {
            console.error('Error kicking member:', error);
            return message.reply({
                embeds: [{
                    title: '❌ Error',
                    description: 'Failed to kick the member. Please try again.',
                    color: 0xFF0000
                }]
            });
        }
    }
};
