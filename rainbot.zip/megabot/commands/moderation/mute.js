const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'mute',
    aliases: ['timeout'],
    description: 'Mute a member',
    usage: '<@user> [duration] [reason]',
    permissions: ['ModerateMembers'],
    botPermissions: ['ModerateMembers'],
    async execute(message, args, client) {
        const member = message.mentions.members.first();
        
        if (!member) {
            return message.reply('❌ Please mention a user to mute!');
        }

        if (!member.moderatable) {
            return message.reply('❌ I cannot mute this user!');
        }

        const duration = args[1] ? ms(args[1]) : null;
        const reason = args.slice(duration ? 2 : 1).join(' ') || 'No reason provided';

        try {
            if (duration) {
                await member.timeout(duration, reason);
                
                const embed = new EmbedBuilder()
                    .setTitle('🔇 Member Muted')
                    .setDescription(`${member} has been muted for ${args[1]}`)
                    .addFields(
                        { name: 'Reason', value: reason },
                        { name: 'Moderator', value: message.author.tag }
                    )
                    .setColor('#FF0000')
                    .setTimestamp();

                await message.reply({ embeds: [embed] });
            } else {
                await member.timeout(28 * 24 * 60 * 60 * 1000, reason); // Max 28 days
                
                const embed = new EmbedBuilder()
                    .setTitle('🔇 Member Muted')
                    .setDescription(`${member} has been muted indefinitely`)
                    .addFields(
                        { name: 'Reason', value: reason },
                        { name: 'Moderator', value: message.author.tag }
                    )
                    .setColor('#FF0000')
                    .setTimestamp();

                await message.reply({ embeds: [embed] });
            }
        } catch (error) {
            console.error('Error muting member:', error);
            return message.reply('❌ Failed to mute member!');
        }
    }
};
