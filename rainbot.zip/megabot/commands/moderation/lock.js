const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'lock',
    aliases: ['lockdown'],
    description: 'Lock a channel to prevent members from sending messages',
    usage: '[channel] [reason]',
    permissions: ['ManageChannels'],
    botPermissions: ['ManageChannels'],
    async execute(message, args, client) {
        const channel = message.mentions.channels.first() || message.channel;
        const reason = args.slice(message.mentions.channels.first() ? 1 : 0).join(' ') || 'No reason provided';

        try {
            await channel.permissionOverwrites.edit(message.guild.id, {
                SendMessages: false
            });

            const embed = new EmbedBuilder()
                .setTitle('🔒 Channel Locked')
                .setDescription(`${channel} has been locked by ${message.author}`)
                .addFields(
                    { name: 'Reason', value: reason }
                )
                .setColor('#FF0000')
                .setTimestamp();

            await channel.send({ embeds: [embed] });

            if (channel.id !== message.channel.id) {
                await message.reply({ embeds: [embed] });
            }

            // Log action
            const stmt = client.db.db.prepare(`
                INSERT INTO mod_actions (guild_id, user_id, moderator_id, action, reason)
                VALUES (?, ?, ?, 'lock', ?)
            `);
            stmt.run(message.guild.id, message.author.id, message.author.id, reason);

        } catch (error) {
            console.error('Error locking channel:', error);
            return message.reply({
                embeds: [{
                    title: '❌ Error',
                    description: 'Failed to lock the channel. Please check my permissions.',
                    color: 0xFF0000
                }]
            });
        }
    }
};
