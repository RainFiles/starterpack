const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'unlock',
    description: 'Unlock a locked channel',
    usage: '[channel]',
    permissions: ['ManageChannels'],
    botPermissions: ['ManageChannels'],
    async execute(message, args, client) {
        const channel = message.mentions.channels.first() || message.channel;

        try {
            await channel.permissionOverwrites.edit(message.guild.id, {
                SendMessages: null
            });

            const embed = new EmbedBuilder()
                .setTitle('🔓 Channel Unlocked')
                .setDescription(`${channel} has been unlocked by ${message.author}`)
                .setColor('#00FF00')
                .setTimestamp();

            await channel.send({ embeds: [embed] });

            if (channel.id !== message.channel.id) {
                await message.reply({ embeds: [embed] });
            }

        } catch (error) {
            console.error('Error unlocking channel:', error);
            return message.reply({
                embeds: [{
                    title: '❌ Error',
                    description: 'Failed to unlock the channel. Please check my permissions.',
                    color: 0xFF0000
                }]
            });
        }
    }
};
