const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'rank',
    aliases: ['level', 'xp', 'stats'],
    description: 'Check your rank and XP',
    usage: '[@user]',
    async execute(message, args, client) {
        const target = message.mentions.users.first() || message.author;
        const userData = client.db.getUser(target.id, message.guild.id);

        const xpNeeded = Math.pow((userData.level + 1) / 0.1, 2);
        const progress = (userData.xp / xpNeeded * 100).toFixed(1);

        const embed = new EmbedBuilder()
            .setTitle(`📊 ${target.username}'s Rank`)
            .setThumbnail(target.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: '🏆 Level', value: `${userData.level}`, inline: true },
                { name: '⭐ XP', value: `${userData.xp.toLocaleString()} / ${Math.floor(xpNeeded).toLocaleString()}`, inline: true },
                { name: '📈 Progress', value: `${progress}%`, inline: true },
                { name: '💰 Coins', value: `${userData.coins.toLocaleString()}`, inline: true },
                { name: '🏦 Bank', value: `${userData.bank.toLocaleString()}`, inline: true },
                { name: '💎 Total Wealth', value: `${(userData.coins + userData.bank).toLocaleString()}`, inline: true }
            )
            .setColor('#FF00FF')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
