const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'leaderboard',
    aliases: ['lb', 'top', 'ranks'],
    description: 'View the server leaderboard',
    usage: '[xp|coins|bank]',
    async execute(message, args, client) {
        const type = args[0]?.toLowerCase() || 'xp';
        
        let orderBy = 'xp DESC';
        let title = '📊 XP Leaderboard';
        
        if (type === 'coins' || type === 'money') {
            orderBy = 'coins DESC';
            title = '💰 Coins Leaderboard';
        } else if (type === 'bank') {
            orderBy = 'bank DESC';
            title = '🏦 Bank Leaderboard';
        } else if (type === 'level') {
            orderBy = 'level DESC, xp DESC';
            title = '🏆 Level Leaderboard';
        }

        const stmt = client.db.db.prepare(`
            SELECT user_id, xp, level, coins, bank 
            FROM users 
            WHERE guild_id = ? 
            ORDER BY ${orderBy} 
            LIMIT 10
        `);
        const topUsers = stmt.all(message.guild.id);

        if (!topUsers.length) {
            return message.reply('❌ No data available for the leaderboard!');
        }

        let description = '';
        for (let i = 0; i < topUsers.length; i++) {
            const user = await client.users.fetch(topUsers[i].user_id).catch(() => null);
            if (!user) continue;

            const medals = ['🥇', '🥈', '🥉'];
            const medal = medals[i] || `**${i + 1}.**`;

            if (type === 'coins' || type === 'money') {
                description += `${medal} ${user.tag} - **${topUsers[i].coins.toLocaleString()}** coins\n`;
            } else if (type === 'bank') {
                description += `${medal} ${user.tag} - **${topUsers[i].bank.toLocaleString()}** coins\n`;
            } else {
                description += `${medal} ${user.tag} - Level **${topUsers[i].level}** (${topUsers[i].xp.toLocaleString()} XP)\n`;
            }
        }

        const embed = new EmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor('#FFD700')
            .setFooter({ text: message.guild.name })
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
