const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'hug',
    description: 'Hug someone',
    usage: '<@user>',
    async execute(message, args, client) {
        const target = message.mentions.users.first();
        
        if (!target) {
            return message.reply('❌ Please mention someone to hug!');
        }

        const embed = new EmbedBuilder()
            .setDescription(`${message.author} hugs ${target}! 🤗`)
            .setColor('#FF69B4')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
