const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'kiss',
    description: 'Kiss someone',
    usage: '<@user>',
    async execute(message, args, client) {
        const target = message.mentions.users.first();
        
        if (!target) {
            return message.reply('❌ Please mention someone to kiss!');
        }

        const embed = new EmbedBuilder()
            .setDescription(`${message.author} kisses ${target}! 💋`)
            .setColor('#FF1493')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
