const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'slap',
    description: 'Slap someone',
    usage: '<@user>',
    async execute(message, args, client) {
        const target = message.mentions.users.first();
        
        if (!target) {
            return message.reply('❌ Please mention someone to slap!');
        }

        const embed = new EmbedBuilder()
            .setDescription(`${message.author} slaps ${target}! 👋💥`)
            .setColor('#FF6347')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
