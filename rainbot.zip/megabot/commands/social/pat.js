const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'pat',
    description: 'Pat someone on the head',
    usage: '<@user>',
    async execute(message, args, client) {
        const target = message.mentions.users.first();
        
        if (!target) {
            return message.reply('❌ Please mention someone to pat!');
        }

        const embed = new EmbedBuilder()
            .setDescription(`${message.author} pats ${target} on the head! 👋`)
            .setColor('#FFB6C1')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
