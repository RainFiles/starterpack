const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'reverse',
    description: 'Reverse text',
    usage: '<text>',
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Please provide text to reverse!');
        }

        const reversed = args.join(' ').split('').reverse().join('');
        
        const embed = new EmbedBuilder()
            .setTitle('🔄 Reversed Text')
            .addFields(
                { name: 'Original', value: args.join(' ') },
                { name: 'Reversed', value: reversed }
            )
            .setColor('#FF00FF')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
