const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'joke',
    aliases: ['dadjoke', 'funny'],
    description: 'Get a random joke',
    async execute(message, args, client) {
        try {
            const { data } = await axios.get('https://official-joke-api.appspot.com/random_joke');

            const embed = new EmbedBuilder()
                .setTitle('😂 Random Joke')
                .addFields(
                    { name: 'Setup', value: data.setup },
                    { name: 'Punchline', value: data.punchline }
                )
                .setColor('#FFFF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            const jokes = [
                { setup: 'Why don\'t scientists trust atoms?', punchline: 'Because they make up everything!' },
                { setup: 'What do you call a fake noodle?', punchline: 'An impasta!' },
                { setup: 'Why did the scarecrow win an award?', punchline: 'He was outstanding in his field!' }
            ];
            
            const joke = jokes[Math.floor(Math.random() * jokes.length)];
            
            const embed = new EmbedBuilder()
                .setTitle('😂 Random Joke')
                .addFields(
                    { name: 'Setup', value: joke.setup },
                    { name: 'Punchline', value: joke.punchline }
                )
                .setColor('#FFFF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        }
    }
};
