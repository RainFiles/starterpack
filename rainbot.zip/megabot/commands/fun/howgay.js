const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'howgay',
    aliases: ['gayrate', 'gay'],
    description: 'Calculate how gay someone is (joke command)',
    usage: '[@user]',
    async execute(message, args, client) {
        const target = message.mentions.users.first() || message.author;
        const percentage = Math.floor(Math.random() * 101);

        const embed = new EmbedBuilder()
            .setTitle('🏳️‍🌈 Gay-O-Meter')
            .setDescription(`${target} is **${percentage}%** gay!`)
            .setColor('#FF69B4')
            .setFooter({ text: 'This is just for fun!' })
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
