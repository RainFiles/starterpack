const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'dice',
    aliases: ['roll', 'diceroll'],
    description: 'Roll a dice',
    usage: '[sides]',
    async execute(message, args, client) {
        const sides = parseInt(args[0]) || 6;
        
        if (sides < 2 || sides > 100) {
            return message.reply('❌ Please provide a number between 2 and 100!');
        }

        const result = Math.floor(Math.random() * sides) + 1;
        
        const embed = new EmbedBuilder()
            .setTitle('🎲 Dice Roll')
            .setDescription(`You rolled a **${result}** (1-${sides})`)
            .setColor('#FF00FF')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
