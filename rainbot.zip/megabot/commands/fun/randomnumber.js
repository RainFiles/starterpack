const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'randomnumber',
    aliases: ['rn', 'random', 'randnum'],
    description: 'Generate a random number',
    usage: '[min] [max]',
    async execute(message, args, client) {
        const min = parseInt(args[0]) || 1;
        const max = parseInt(args[1]) || 100;

        if (min >= max) {
            return message.reply('❌ Minimum must be less than maximum!');
        }

        const random = Math.floor(Math.random() * (max - min + 1)) + min;

        const embed = new EmbedBuilder()
            .setTitle('🎲 Random Number')
            .setDescription(`**${random}**`)
            .addFields({ name: 'Range', value: `${min} - ${max}` })
            .setColor('#00FF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
