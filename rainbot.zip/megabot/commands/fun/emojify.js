module.exports = {
    name: 'emojify',
    description: 'Convert text to emojis',
    usage: '<text>',
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply('❌ Please provide text to emojify!');
        }

        const text = args.join(' ').toLowerCase();
        const emojified = text.split('').map(char => {
            if (char >= 'a' && char <= 'z') {
                return `:regional_indicator_${char}:`;
            } else if (char >= '0' && char <= '9') {
                const nums = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
                return `:${nums[parseInt(char)]}:`;
            } else if (char === ' ') {
                return '   ';
            } else {
                return char;
            }
        }).join('');

        if (emojified.length > 2000) {
            return message.reply('❌ Text is too long to emojify!');
        }

        await message.reply(emojified);
    }
};
