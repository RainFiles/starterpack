const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'ship',
    description: 'Ship two users together',
    usage: '<@user1> <@user2>',
    async execute(message, args, client) {
        const users = message.mentions.users;
        
        if (users.size < 2) {
            return message.reply('❌ Please mention 2 users to ship!\nExample: `!ship @user1 @user2`');
        }

        const user1 = users.first();
        const user2 = users.last();
        
        const percentage = Math.floor(Math.random() * 101);
        
        let rating = '';
        if (percentage < 20) rating = '💔 Not meant to be...';
        else if (percentage < 40) rating = '❤️ Could work with effort';
        else if (percentage < 60) rating = '💕 Pretty good match!';
        else if (percentage < 80) rating = '💖 Great couple!';
        else rating = '💞 Perfect match!';

        const shipName = user1.username.slice(0, Math.ceil(user1.username.length / 2)) + 
                        user2.username.slice(Math.floor(user2.username.length / 2));

        const embed = new EmbedBuilder()
            .setTitle('💖 Love Calculator')
            .setDescription(`${user1} + ${user2}\n\n**${percentage}%** compatible!\n${rating}`)
            .addFields({ name: 'Ship Name', value: shipName })
            .setColor('#FF69B4')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
