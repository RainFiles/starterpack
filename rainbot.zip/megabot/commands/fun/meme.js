const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'meme',
    aliases: ['reddit', 'funny'],
    description: 'Get a random meme from Reddit',
    async execute(message, args, client) {
        try {
            const subreddits = ['memes', 'dankmemes', 'wholesomememes', 'me_irl', 'funny'];
            const subreddit = subreddits[Math.floor(Math.random() * subreddits.length)];
            
            const { data } = await axios.get(`https://www.reddit.com/r/${subreddit}/random.json`);
            const post = data[0].data.children[0].data;

            const embed = new EmbedBuilder()
                .setTitle(post.title)
                .setURL(`https://reddit.com${post.permalink}`)
                .setImage(post.url)
                .setColor('#FF4500')
                .setFooter({ text: `👍 ${post.ups} | r/${subreddit}` })
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            await message.reply('❌ Failed to fetch meme. Try again!');
        }
    }
};
