const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'coinflip',
    aliases: ['flip', 'coin'],
    description: 'Flip a coin',
    async execute(message, args, client) {
        const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
        
        const embed = new EmbedBuilder()
            .setTitle('🪙 Coin Flip')
            .setDescription(`The coin landed on: **${result}**!`)
            .setColor(result === 'Heads' ? '#FFD700' : '#C0C0C0')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
