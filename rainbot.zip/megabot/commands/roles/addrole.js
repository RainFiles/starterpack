const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'addrole',
    aliases: ['giverole', 'roleadd'],
    description: 'Add a role to a member',
    usage: '<@user> <@role>',
    permissions: ['ManageRoles'],
    botPermissions: ['ManageRoles'],
    async execute(message, args, client) {
        const member = message.mentions.members.first();
        const role = message.mentions.roles.first();

        if (!member || !role) {
            return message.reply('❌ Usage: `!addrole @user @role`');
        }

        if (role.position >= message.guild.members.me.roles.highest.position) {
            return message.reply('❌ I cannot manage this role due to role hierarchy!');
        }

        if (role.position >= message.member.roles.highest.position) {
            return message.reply('❌ You cannot manage this role due to role hierarchy!');
        }

        if (member.roles.cache.has(role.id)) {
            return message.reply('❌ User already has this role!');
        }

        try {
            await member.roles.add(role);

            const embed = new EmbedBuilder()
                .setTitle('✅ Role Added')
                .setDescription(`Added ${role} to ${member}`)
                .setColor('#00FF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error adding role:', error);
            return message.reply('❌ Failed to add role!');
        }
    }
};
