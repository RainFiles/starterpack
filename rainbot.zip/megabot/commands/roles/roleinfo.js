const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'roleinfo',
    aliases: ['rinfo', 'role'],
    description: 'Get information about a role',
    usage: '<@role>',
    async execute(message, args, client) {
        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);

        if (!role) {
            return message.reply('❌ Please mention a valid role or provide a role ID!');
        }

        const createdAt = Math.floor(role.createdTimestamp / 1000);

        const embed = new EmbedBuilder()
            .setTitle(`🎭 Role Information: ${role.name}`)
            .addFields(
                { name: '🆔 ID', value: role.id, inline: true },
                { name: '🎨 Color', value: role.hexColor, inline: true },
                { name: '👥 Members', value: `${role.members.size}`, inline: true },
                { name: '📅 Created', value: `<t:${createdAt}:R>`, inline: true },
                { name: '🔢 Position', value: `${role.position}`, inline: true },
                { name: '🎯 Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
                { name: '📌 Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
                { name: '🤖 Managed', value: role.managed ? 'Yes' : 'No', inline: true }
            )
            .setColor(role.hexColor)
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
