const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'removerole',
    aliases: ['takerole', 'roleremove'],
    description: 'Remove a role from a member',
    usage: '<@user> <@role>',
    permissions: ['ManageRoles'],
    botPermissions: ['ManageRoles'],
    async execute(message, args, client) {
        const member = message.mentions.members.first();
        const role = message.mentions.roles.first();

        if (!member || !role) {
            return message.reply('❌ Usage: `!removerole @user @role`');
        }

        if (role.position >= message.guild.members.me.roles.highest.position) {
            return message.reply('❌ I cannot manage this role due to role hierarchy!');
        }

        if (!member.roles.cache.has(role.id)) {
            return message.reply('❌ User doesn\'t have this role!');
        }

        try {
            await member.roles.remove(role);

            const embed = new EmbedBuilder()
                .setTitle('✅ Role Removed')
                .setDescription(`Removed ${role} from ${member}`)
                .setColor('#00FF00')
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error removing role:', error);
            return message.reply('❌ Failed to remove role!');
        }
    }
};
