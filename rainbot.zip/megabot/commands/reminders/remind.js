const { EmbedBuilder } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'remind',
    aliases: ['reminder', 'remindme', 'rm'],
    description: 'Set a reminder',
    usage: '<time> <message>',
    async execute(message, args, client) {
        if (args.length < 2) {
            return message.reply('❌ Usage: `!remind <time> <message>`\nExample: `!remind 1h Take a break`');
        }

        const time = ms(args[0]);
        const reminderMsg = args.slice(1).join(' ');

        if (!time || time < 1000) {
            return message.reply('❌ Invalid time! Use format like: 1h, 30m, 1d');
        }

        if (time > 1000 * 60 * 60 * 24 * 365) {
            return message.reply('❌ Reminder time cannot exceed 1 year!');
        }

        const remindAt = new Date(Date.now() + time);

        const stmt = client.db.db.prepare(`
            INSERT INTO reminders (user_id, guild_id, channel_id, message, remind_at)
            VALUES (?, ?, ?, ?, ?)
        `);
        stmt.run(
            message.author.id,
            message.guild.id,
            message.channel.id,
            reminderMsg,
            remindAt.toISOString()
        );

        const embed = new EmbedBuilder()
            .setTitle('⏰ Reminder Set')
            .setDescription(`I'll remind you in **${args[0]}**`)
            .addFields(
                { name: 'Message', value: reminderMsg },
                { name: 'Time', value: `<t:${Math.floor(remindAt.getTime() / 1000)}:R>` }
            )
            .setColor('#00FF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
