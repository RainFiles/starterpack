const { EmbedBuilder } = require('discord.js');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

module.exports = {
    name: 'sshx',
    description: 'Create an SSHX session for remote terminal access (Admin only)',
    usage: '',
    permissions: ['Administrator'],
    ownerOnly: true,
    async execute(message, args, client) {
        const embed = new EmbedBuilder()
            .setTitle('🔐 Creating SSHX Session')
            .setDescription('Setting up secure SSH session...')
            .setColor('#FFFF00')
            .setTimestamp();

        const statusMsg = await message.reply({ embeds: [embed] });

        try {
            // Check if sshx is installed
            try {
                await execPromise('which sshx');
            } catch {
                // Install sshx
                await execPromise('curl -sSf https://sshx.io/get | sh');
            }

            // Start sshx session
            const { stdout, stderr } = await execPromise('sshx --quiet 2>&1 &', {
                timeout: 10000
            });

            let sessionUrl = '';
            const urlMatch = stdout.match(/https:\/\/sshx\.io\/s\/[a-zA-Z0-9]+/);
            if (urlMatch) {
                sessionUrl = urlMatch[0];
            }

            const successEmbed = new EmbedBuilder()
                .setTitle('✅ SSHX Session Created')
                .setDescription('Your SSH session is ready!')
                .addFields(
                    { name: '🔗 Session URL', value: sessionUrl || 'Check terminal for URL' },
                    { name: '⚠️ Security Warning', value: 'This link provides terminal access to your server. Keep it private!' },
                    { name: '📝 Usage', value: 'Click the URL to access the terminal in your browser' },
                    { name: '⏰ Session', value: 'Session will remain active until closed' }
                )
                .setColor('#00FF00')
                .setTimestamp();

            await statusMsg.edit({ embeds: [successEmbed] });

            // Log session
            const stmt = client.db.db.prepare(`
                INSERT INTO vps_sessions (guild_id, user_id, session_type, session_id, active)
                VALUES (?, ?, 'sshx', ?, 1)
            `);
            stmt.run(message.guild.id, message.author.id, sessionUrl);

            // Store in client for management
            client.sshSessions.set(message.author.id, {
                type: 'sshx',
                url: sessionUrl,
                created: Date.now()
            });

        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Failed to Create Session')
                .setDescription(`\`\`\`\n${error.message}\n\`\`\``)
                .addFields(
                    { name: '💡 Tip', value: 'Make sure sshx is installed or the bot has permissions to install it.' }
                )
                .setColor('#FF0000')
                .setTimestamp();

            await statusMsg.edit({ embeds: [errorEmbed] });
        }
    }
};
