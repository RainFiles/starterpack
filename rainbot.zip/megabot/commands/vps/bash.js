const { EmbedBuilder } = require('discord.js');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

module.exports = {
    name: 'bash',
    aliases: ['exec', 'shell', 'cmd', 'execute'],
    description: 'Execute bash commands on the VPS (Admin only)',
    usage: '<command>',
    permissions: ['Administrator'],
    ownerOnly: true,
    async execute(message, args, client) {
        if (!args.length) {
            return message.reply({
                embeds: [{
                    title: '❌ Invalid Usage',
                    description: 'Usage: `!bash <command>`\nExample: `!bash sudo apt update`',
                    color: 0xFF0000
                }]
            });
        }

        const command = args.join(' ');

        // Security check - prevent dangerous commands
        const dangerousCommands = ['rm -rf /', 'mkfs', 'dd if=', ':(){:|:&};:', 'fork bomb'];
        if (dangerousCommands.some(cmd => command.toLowerCase().includes(cmd))) {
            return message.reply({
                embeds: [{
                    title: '🚫 Command Blocked',
                    description: 'This command has been blocked for security reasons!',
                    color: 0xFF0000
                }]
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('⚙️ Executing Command')
            .setDescription(`\`\`\`bash\n$ ${command}\n\`\`\``)
            .setColor('#FFFF00')
            .setTimestamp();

        const statusMsg = await message.reply({ embeds: [embed] });

        try {
            const { stdout, stderr } = await execPromise(command, {
                timeout: 30000,
                maxBuffer: 1024 * 1024 * 10 // 10MB buffer
            });

            let output = '';
            if (stdout) output += stdout;
            if (stderr) output += `\nSTDERR:\n${stderr}`;

            if (!output) output = 'Command executed successfully with no output.';

            // Split output if too long
            const chunks = splitMessage(output, 1990);

            for (let i = 0; i < chunks.length; i++) {
                const resultEmbed = new EmbedBuilder()
                    .setTitle(`✅ Command Output ${chunks.length > 1 ? `(${i + 1}/${chunks.length})` : ''}`)
                    .setDescription(`\`\`\`bash\n$ ${command}\n\`\`\`\n\`\`\`\n${chunks[i]}\n\`\`\``)
                    .setColor('#00FF00')
                    .setTimestamp();

                if (i === 0) {
                    await statusMsg.edit({ embeds: [resultEmbed] });
                } else {
                    await message.channel.send({ embeds: [resultEmbed] });
                }
            }

            // Log command execution
            const stmt = client.db.db.prepare(`
                INSERT INTO vps_sessions (guild_id, user_id, session_type, host, active)
                VALUES (?, ?, 'bash_exec', ?, 0)
            `);
            stmt.run(message.guild.id, message.author.id, 'localhost');

        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Command Failed')
                .setDescription(`\`\`\`bash\n$ ${command}\n\`\`\`\n\`\`\`\n${error.message}\n\`\`\``)
                .setColor('#FF0000')
                .setTimestamp();

            await statusMsg.edit({ embeds: [errorEmbed] });
        }
    }
};

function splitMessage(text, maxLength = 1990) {
    if (text.length <= maxLength) return [text];
    
    const chunks = [];
    let current = '';
    
    const lines = text.split('\n');
    for (const line of lines) {
        if ((current + line + '\n').length > maxLength) {
            chunks.push(current);
            current = line + '\n';
        } else {
            current += line + '\n';
        }
    }
    
    if (current) chunks.push(current);
    return chunks;
}
