const { EmbedBuilder } = require('discord.js');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

module.exports = {
    name: 'tmate',
    description: 'Create a tmate session for remote terminal access (Admin only)',
    usage: '',
    permissions: ['Administrator'],
    ownerOnly: true,
    async execute(message, args, client) {
        const embed = new EmbedBuilder()
            .setTitle('🔐 Creating Tmate Session')
            .setDescription('Setting up secure tmate session...')
            .setColor('#FFFF00')
            .setTimestamp();

        const statusMsg = await message.reply({ embeds: [embed] });

        try {
            // Check if tmate is installed
            try {
                await execPromise('which tmate');
            } catch {
                // Install tmate
                await execPromise('sudo apt-get install -y tmate || sudo yum install -y tmate');
            }

            // Create tmate session and get connection string
            const { stdout, stderr } = await execPromise('tmate -F 2>&1 | grep -E "ssh session|web session"', {
                timeout: 15000
            });

            const sshMatch = stdout.match(/ssh\s+([^\s]+)/);
            const webMatch = stdout.match(/https:\/\/[^\s]+/);

            const sshUrl = sshMatch ? sshMatch[1] : 'Not available';
            const webUrl = webMatch ? webMatch[0] : 'Not available';

            const successEmbed = new EmbedBuilder()
                .setTitle('✅ Tmate Session Created')
                .setDescription('Your tmate session is ready!')
                .addFields(
                    { name: '🖥️ SSH Connection', value: `\`ssh ${sshUrl}\`` },
                    { name: '🌐 Web Access', value: webUrl },
                    { name: '⚠️ Security Warning', value: 'These connections provide full terminal access. Keep them private!' },
                    { name: '📝 Usage', value: 'Use the SSH command in your terminal or click the web URL' },
                    { name: '⏰ Session', value: 'Session will remain active until closed' }
                )
                .setColor('#00FF00')
                .setTimestamp();

            await statusMsg.edit({ embeds: [successEmbed] });

            // Log session
            const stmt = client.db.db.prepare(`
                INSERT INTO vps_sessions (guild_id, user_id, session_type, session_id, active)
                VALUES (?, ?, 'tmate', ?, 1)
            `);
            stmt.run(message.guild.id, message.author.id, sshUrl);

            // Store in client
            client.sshSessions.set(`tmate_${message.author.id}`, {
                type: 'tmate',
                ssh: sshUrl,
                web: webUrl,
                created: Date.now()
            });

        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Failed to Create Session')
                .setDescription(`\`\`\`\n${error.message}\n\`\`\``)
                .addFields(
                    { name: '💡 Tip', value: 'Make sure tmate is installed: `sudo apt-get install tmate`' }
                )
                .setColor('#FF0000')
                .setTimestamp();

            await statusMsg.edit({ embeds: [errorEmbed] });
        }
    }
};
