const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'afk',
    description: 'Set your AFK status',
    usage: '[reason]',
    async execute(message, args, client) {
        const reason = args.join(' ') || 'AFK';

        const stmt = client.db.db.prepare(`
            INSERT OR REPLACE INTO afk (user_id, reason, started_at)
            VALUES (?, ?, datetime('now'))
        `);
        stmt.run(message.author.id, reason);

        const embed = new EmbedBuilder()
            .setDescription(`💤 ${message.author} is now AFK: ${reason}`)
            .setColor('#FFFF00')
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
