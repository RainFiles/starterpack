const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'roles',
    aliases: ['rolelist', 'serverroles'],
    description: 'List all server roles',
    async execute(message, args, client) {
        const roles = message.guild.roles.cache
            .sort((a, b) => b.position - a.position)
            .filter(r => r.id !== message.guild.id)
            .map(r => r)
            .join(', ');

        const embed = new EmbedBuilder()
            .setTitle(`🎭 Server Roles (${message.guild.roles.cache.size - 1})`)
            .setDescription(roles || 'No roles')
            .setColor('#FF00FF')
            .setFooter({ text: message.guild.name })
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
