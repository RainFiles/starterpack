const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'emojis',
    aliases: ['emojilist', 'serveremojis'],
    description: 'List all server emojis',
    async execute(message, args, client) {
        const emojis = message.guild.emojis.cache;

        if (!emojis.size) {
            return message.reply('❌ This server has no custom emojis!');
        }

        const animated = emojis.filter(e => e.animated);
        const static = emojis.filter(e => !e.animated);

        const embed = new EmbedBuilder()
            .setTitle(`😀 Server Emojis (${emojis.size}/${message.guild.premiumTier >= 1 ? 100 : 50})`)
            .setColor('#FF00FF')
            .setTimestamp();

        if (static.size > 0) {
            const staticList = static.map(e => `${e} \`:${e.name}:\``).join(' ');
            embed.addFields({ name: `Static Emojis (${static.size})`, value: staticList.slice(0, 1024) });
        }

        if (animated.size > 0) {
            const animatedList = animated.map(e => `${e} \`:${e.name}:\``).join(' ');
            embed.addFields({ name: `Animated Emojis (${animated.size})`, value: animatedList.slice(0, 1024) });
        }

        await message.reply({ embeds: [embed] });
    }
};
