const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'members',
    aliases: ['membercount', 'mc'],
    description: 'View server member statistics',
    async execute(message, args, client) {
        const { guild } = message;
        
        const members = guild.members.cache;
        const bots = members.filter(m => m.user.bot).size;
        const humans = members.size - bots;
        const online = members.filter(m => m.presence?.status !== 'offline').size;

        const embed = new EmbedBuilder()
            .setTitle(`👥 ${guild.name} Members`)
            .addFields(
                { name: '📊 Total Members', value: `${guild.memberCount}`, inline: true },
                { name: '👨 Humans', value: `${humans}`, inline: true },
                { name: '🤖 Bots', value: `${bots}`, inline: true },
                { name: '🟢 Online', value: `${online}`, inline: true },
                { name: '🚀 Boosters', value: `${guild.premiumSubscriptionCount || 0}`, inline: true },
                { name: '📈 Boost Level', value: `${guild.premiumTier}`, inline: true }
            )
            .setColor('#FF00FF')
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
