const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

class BotDatabase {
    constructor() {
        const dbPath = path.join(__dirname, '../data');
        if (!fs.existsSync(dbPath)) {
            fs.mkdirSync(dbPath, { recursive: true });
        }
        
        this.db = new Database(path.join(dbPath, 'megabot.db'));
        this.db.pragma('journal_mode = WAL');
    }

    async init() {
        // Guild Settings
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS guilds (
                guild_id TEXT PRIMARY KEY,
                prefix TEXT DEFAULT '!',
                language TEXT DEFAULT 'en',
                setup_complete INTEGER DEFAULT 0,
                ticket_category TEXT,
                ticket_channel TEXT,
                ticket_counter INTEGER DEFAULT 0,
                log_channel TEXT,
                mod_log_channel TEXT,
                join_log_channel TEXT,
                leave_log_channel TEXT,
                message_log_channel TEXT,
                voice_log_channel TEXT,
                welcome_enabled INTEGER DEFAULT 0,
                welcome_channel TEXT,
                welcome_message TEXT,
                goodbye_enabled INTEGER DEFAULT 0,
                goodbye_channel TEXT,
                goodbye_message TEXT,
                autorole_enabled INTEGER DEFAULT 0,
                autorole_id TEXT,
                level_enabled INTEGER DEFAULT 1,
                level_channel TEXT,
                level_message TEXT,
                premium INTEGER DEFAULT 0,
                premium_expires TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Tickets
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS tickets (
                ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                category TEXT DEFAULT 'general',
                status TEXT DEFAULT 'open',
                claimed_by TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                closed_at DATETIME,
                transcript TEXT
            )
        `);

        // Ticket Categories
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS ticket_categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                name TEXT NOT NULL,
                emoji TEXT,
                color TEXT,
                description TEXT,
                position INTEGER DEFAULT 0
            )
        `);

        // Users
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT NOT NULL,
                guild_id TEXT NOT NULL,
                xp INTEGER DEFAULT 0,
                level INTEGER DEFAULT 0,
                coins INTEGER DEFAULT 0,
                bank INTEGER DEFAULT 0,
                daily_streak INTEGER DEFAULT 0,
                last_daily DATETIME,
                last_weekly DATETIME,
                last_monthly DATETIME,
                last_work DATETIME,
                last_crime DATETIME,
                last_rob DATETIME,
                bio TEXT,
                rep INTEGER DEFAULT 0,
                last_rep DATETIME,
                inventory TEXT DEFAULT '[]',
                equipped TEXT DEFAULT '{}',
                marriage_partner TEXT,
                marriage_date DATETIME,
                warnings INTEGER DEFAULT 0,
                muted INTEGER DEFAULT 0,
                mute_expires DATETIME,
                PRIMARY KEY (user_id, guild_id)
            )
        `);

        // Warnings
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                moderator_id TEXT NOT NULL,
                reason TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Moderation Actions
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS mod_actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                moderator_id TEXT NOT NULL,
                action TEXT NOT NULL,
                reason TEXT,
                duration TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Reminders
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                guild_id TEXT,
                channel_id TEXT NOT NULL,
                message TEXT NOT NULL,
                remind_at DATETIME NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                completed INTEGER DEFAULT 0
            )
        `);

        // Giveaways
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS giveaways (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                message_id TEXT NOT NULL,
                prize TEXT NOT NULL,
                winners INTEGER DEFAULT 1,
                host_id TEXT NOT NULL,
                ends_at DATETIME NOT NULL,
                ended INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Polls
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS polls (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                message_id TEXT NOT NULL,
                question TEXT NOT NULL,
                options TEXT NOT NULL,
                creator_id TEXT NOT NULL,
                ends_at DATETIME,
                ended INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Suggestions
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS suggestions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                message_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                suggestion TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                upvotes INTEGER DEFAULT 0,
                downvotes INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // AFK Status
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS afk (
                user_id TEXT PRIMARY KEY,
                reason TEXT,
                started_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Custom Commands
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS custom_commands (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                trigger TEXT NOT NULL,
                response TEXT NOT NULL,
                created_by TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Reaction Roles
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS reaction_roles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                message_id TEXT NOT NULL,
                emoji TEXT NOT NULL,
                role_id TEXT NOT NULL
            )
        `);

        // AutoMod Rules
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS automod_rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                rule_type TEXT NOT NULL,
                enabled INTEGER DEFAULT 1,
                action TEXT DEFAULT 'delete',
                whitelist TEXT DEFAULT '[]',
                settings TEXT DEFAULT '{}'
            )
        `);

        // Starboard
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS starboard (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                message_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                starboard_message_id TEXT,
                stars INTEGER DEFAULT 0
            )
        `);

        // Economy Items
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS shop_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                name TEXT NOT NULL,
                description TEXT,
                price INTEGER NOT NULL,
                role_id TEXT,
                stock INTEGER DEFAULT -1,
                category TEXT DEFAULT 'general'
            )
        `);

        // Pets
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS pets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                guild_id TEXT NOT NULL,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                level INTEGER DEFAULT 1,
                xp INTEGER DEFAULT 0,
                hunger INTEGER DEFAULT 100,
                happiness INTEGER DEFAULT 100,
                health INTEGER DEFAULT 100,
                last_fed DATETIME,
                last_played DATETIME,
                obtained_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Achievements
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS achievements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                guild_id TEXT NOT NULL,
                achievement_id TEXT NOT NULL,
                unlocked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, guild_id, achievement_id)
            )
        `);

        // Clans/Guilds
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS clans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                name TEXT NOT NULL,
                tag TEXT,
                owner_id TEXT NOT NULL,
                description TEXT,
                level INTEGER DEFAULT 1,
                xp INTEGER DEFAULT 0,
                bank INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Clan Members
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS clan_members (
                clan_id INTEGER NOT NULL,
                user_id TEXT NOT NULL,
                rank TEXT DEFAULT 'member',
                joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (clan_id, user_id),
                FOREIGN KEY (clan_id) REFERENCES clans(id)
            )
        `);

        // VPS Sessions
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS vps_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                session_type TEXT NOT NULL,
                session_id TEXT,
                host TEXT,
                port INTEGER,
                username TEXT,
                active INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Command Usage Stats
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS command_stats (
                command TEXT NOT NULL,
                guild_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                uses INTEGER DEFAULT 1,
                last_used DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (command, guild_id, user_id)
            )
        `);

        console.log('✓ Database initialized with all tables');
    }

    // Helper methods
    getGuild(guildId) {
        const stmt = this.db.prepare('SELECT * FROM guilds WHERE guild_id = ?');
        let guild = stmt.get(guildId);
        
        if (!guild) {
            const insert = this.db.prepare('INSERT INTO guilds (guild_id) VALUES (?)');
            insert.run(guildId);
            guild = stmt.get(guildId);
        }
        
        return guild;
    }

    updateGuild(guildId, data) {
        const keys = Object.keys(data);
        const values = Object.values(data);
        const setClause = keys.map(key => `${key} = ?`).join(', ');
        
        const stmt = this.db.prepare(`UPDATE guilds SET ${setClause} WHERE guild_id = ?`);
        return stmt.run(...values, guildId);
    }

    getUser(userId, guildId) {
        const stmt = this.db.prepare('SELECT * FROM users WHERE user_id = ? AND guild_id = ?');
        let user = stmt.get(userId, guildId);
        
        if (!user) {
            const insert = this.db.prepare('INSERT INTO users (user_id, guild_id) VALUES (?, ?)');
            insert.run(userId, guildId);
            user = stmt.get(userId, guildId);
        }
        
        return user;
    }

    updateUser(userId, guildId, data) {
        const keys = Object.keys(data);
        const values = Object.values(data);
        const setClause = keys.map(key => `${key} = ?`).join(', ');
        
        const stmt = this.db.prepare(`UPDATE users SET ${setClause} WHERE user_id = ? AND guild_id = ?`);
        return stmt.run(...values, userId, guildId);
    }

    addXP(userId, guildId, amount) {
        const user = this.getUser(userId, guildId);
        const newXP = user.xp + amount;
        const newLevel = Math.floor(0.1 * Math.sqrt(newXP));
        
        this.updateUser(userId, guildId, { xp: newXP, level: newLevel });
        
        return {
            oldLevel: user.level,
            newLevel: newLevel,
            leveledUp: newLevel > user.level
        };
    }

    addCoins(userId, guildId, amount) {
        const user = this.getUser(userId, guildId);
        this.updateUser(userId, guildId, { coins: user.coins + amount });
    }

    close() {
        this.db.close();
    }
}

module.exports = BotDatabase;
