# 🚀 DEPLOYMENT GUIDE - Ultimate Discord MegaBot

## Complete Step-by-Step Deployment Instructions

---

## 📋 Prerequisites

Before deploying, ensure you have:
- ✅ Node.js 18.0.0 or higher
- ✅ npm or yarn package manager
- ✅ Discord Bot Token
- ✅ Server/VPS (for hosting) OR use your local machine

---

## 🎯 Method 1: Local Deployment (Testing)

### Step 1: Prepare Your System
```bash
# Update system (Ubuntu/Debian)
sudo apt update && sudo apt upgrade -y

# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node --version  # Should be v18.x.x or higher
npm --version
```

### Step 2: Clone/Download Bot
```bash
# If using Git
git clone <your-repo-url>
cd megabot

# OR if you have the files locally
cd /home/claude/megabot
```

### Step 3: Install Dependencies
```bash
npm install
```

### Step 4: Configure Bot
```bash
# Copy example environment file
cp .env.example .env

# Edit configuration
nano .env
```

Add your bot token:
```env
DISCORD_TOKEN=YOUR_BOT_TOKEN_HERE
PREFIX=!
OWNER_IDS=YOUR_DISCORD_USER_ID
SUPPORT_SERVER=https://discord.gg/your_server
```

### Step 5: Create Discord Bot

1. Go to https://discord.com/developers/applications
2. Click "New Application"
3. Name your application
4. Go to "Bot" tab
5. Click "Add Bot"
6. Copy the token and add to `.env`

### Step 6: Enable Intents

In Discord Developer Portal → Bot → Privileged Gateway Intents:
- ✅ PRESENCE INTENT
- ✅ SERVER MEMBERS INTENT
- ✅ MESSAGE CONTENT INTENT

### Step 7: Invite Bot to Server

Generate invite URL:
1. Go to OAuth2 → URL Generator
2. Select scopes: `bot` and `applications.commands`
3. Select permissions: `Administrator` (or specific permissions)
4. Copy the generated URL
5. Open in browser and add to your server

### Step 8: Start Bot
```bash
npm start
```

You should see:
```
✓ Bot is online as YourBotName#1234
✓ Serving 1 servers
✓ Loaded 75+ commands
```

### Step 9: Test Bot
In Discord:
```
!ping
!help
!setup
```

---

## 🌐 Method 2: VPS Deployment (Production)

### Recommended VPS Providers:
- DigitalOcean ($5/month)
- Linode ($5/month)
- Vultr ($5/month)
- AWS EC2 (Free tier available)
- Google Cloud (Free tier available)

### Step 1: Set Up VPS
```bash
# SSH into your VPS
ssh root@your_vps_ip

# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs git

# Install PM2 (Process Manager)
sudo npm install -g pm2
```

### Step 2: Clone Bot to VPS
```bash
# Clone your repository
git clone <your-repo-url>
cd megabot

# Install dependencies
npm install

# Configure
cp .env.example .env
nano .env
# Add your bot token and configuration
```

### Step 3: Start with PM2
```bash
# Start bot
pm2 start index.js --name megabot

# Save PM2 configuration
pm2 save

# Enable PM2 startup on boot
pm2 startup
# Run the command it outputs
```

### Step 4: Monitor Bot
```bash
# View logs
pm2 logs megabot

# View status
pm2 status

# Restart bot
pm2 restart megabot

# Stop bot
pm2 stop megabot
```

---

## 🐳 Method 3: Docker Deployment

### Step 1: Create Dockerfile
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install --production

COPY . .

CMD ["node", "index.js"]
```

### Step 2: Create docker-compose.yml
```yaml
version: '3.8'

services:
  megabot:
    build: .
    restart: unless-stopped
    environment:
      - DISCORD_TOKEN=${DISCORD_TOKEN}
      - PREFIX=${PREFIX}
      - OWNER_IDS=${OWNER_IDS}
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
```

### Step 3: Deploy with Docker
```bash
# Build and start
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down

# Restart
docker-compose restart
```

---

## ☁️ Method 4: Cloud Platform Deployment

### Heroku Deployment

1. **Install Heroku CLI**
```bash
curl https://cli-assets.heroku.com/install.sh | sh
```

2. **Create Heroku App**
```bash
heroku login
heroku create your-bot-name
```

3. **Add Procfile**
```
worker: node index.js
```

4. **Set Config Vars**
```bash
heroku config:set DISCORD_TOKEN=your_token
heroku config:set PREFIX=!
heroku config:set OWNER_IDS=your_id
```

5. **Deploy**
```bash
git add .
git commit -m "Deploy to Heroku"
git push heroku main
```

6. **Scale Worker**
```bash
heroku ps:scale worker=1
```

---

## 🔧 Configuration Options

### Environment Variables (.env)

```env
# Required
DISCORD_TOKEN=your_bot_token_here
PREFIX=!
OWNER_IDS=123456789,987654321

# Optional
SUPPORT_SERVER=https://discord.gg/your_server
VOTE_LINK=https://top.gg/bot/your_bot_id
WEBSITE_LINK=https://yourwebsite.com

# API Keys (Optional)
YOUTUBE_API_KEY=
SPOTIFY_CLIENT_ID=
SPOTIFY_CLIENT_SECRET=
GENIUS_API_KEY=
WEATHER_API_KEY=
GIPHY_API_KEY=

# Advanced
NODE_ENV=production
LOG_LEVEL=info
```

---

## 🛡️ Security Best Practices

### 1. Protect Your Token
```bash
# Never commit .env to Git
echo ".env" >> .gitignore

# Use environment variables on VPS
export DISCORD_TOKEN="your_token"
```

### 2. Firewall Setup (VPS)
```bash
# Enable UFW
sudo ufw enable

# Allow SSH
sudo ufw allow 22

# Allow HTTP/HTTPS (if needed)
sudo ufw allow 80
sudo ufw allow 443
```

### 3. Regular Updates
```bash
# Update bot
git pull
npm install
pm2 restart megabot

# Update system
sudo apt update && sudo apt upgrade -y
```

### 4. Backup Database
```bash
# Backup database
cp data/megabot.db data/megabot_backup_$(date +%Y%m%d).db

# Automated backup (add to crontab)
0 0 * * * cp /path/to/megabot/data/megabot.db /path/to/backup/megabot_$(date +\%Y\%m\%d).db
```

---

## 📊 Monitoring & Maintenance

### PM2 Dashboard
```bash
# Install PM2 web dashboard
pm2 install pm2-server-monit

# View metrics
pm2 monit
```

### Bot Status Monitoring
```bash
# Check bot status every 5 minutes
*/5 * * * * pm2 status megabot | grep -q "online" || pm2 restart megabot
```

### Log Management
```bash
# Rotate PM2 logs
pm2 install pm2-logrotate

# View logs
pm2 logs megabot --lines 100
```

---

## 🚨 Troubleshooting

### Bot Won't Start
```bash
# Check Node version
node --version  # Must be 18+

# Check dependencies
npm install

# Check .env file
cat .env
```

### Bot Disconnects
```bash
# Check internet connection
ping discord.com

# Check PM2 logs
pm2 logs megabot --err

# Restart bot
pm2 restart megabot
```

### Database Errors
```bash
# Reset database (WARNING: Deletes all data)
rm data/megabot.db
pm2 restart megabot
```

### Permission Errors
```bash
# Ensure bot has Administrator permission
# Or grant specific permissions in Discord

# Check file permissions
chmod 644 .env
chmod 755 index.js
```

---

## 🔄 Updating the Bot

### Method 1: Git Pull
```bash
cd megabot
git pull origin main
npm install
pm2 restart megabot
```

### Method 2: Manual Update
```bash
# Backup current version
cp -r megabot megabot_backup

# Replace files
# Upload new files

# Restart
pm2 restart megabot
```

---

## 📈 Scaling

### Multiple Instances
```bash
# Run multiple instances
pm2 start index.js -i 2 --name megabot

# Use clustering for load balancing
pm2 start index.js -i max --name megabot
```

### Database Optimization
```sql
-- Add indexes for better performance
CREATE INDEX idx_users_guild ON users(guild_id);
CREATE INDEX idx_tickets_status ON tickets(status);
```

---

## ✅ Post-Deployment Checklist

- [ ] Bot is online and responding
- [ ] All intents are enabled
- [ ] Bot has proper permissions in server
- [ ] Database is working (check `!balance`)
- [ ] Commands work (`!help`, `!ping`)
- [ ] Logging is configured
- [ ] PM2 is set to start on boot
- [ ] Backups are configured
- [ ] Firewall is configured (if VPS)
- [ ] Monitoring is set up
- [ ] .env file is secured
- [ ] Git repository is private (if using Git)

---

## 🎉 Success!

Your bot is now deployed and running 24/7!

### Next Steps:
1. Run `!setup` in your Discord server
2. Configure ticket system with `!ticketsetup`
3. Set up welcome messages and auto-roles
4. Configure moderation logging
5. Customize economy settings
6. Add your server to bot listing sites

---

## 🆘 Support

If you encounter issues:
1. Check the logs: `pm2 logs megabot`
2. Review this guide
3. Check Discord Developer Portal
4. Create a GitHub issue
5. Join the support server

---

**Your Ultimate Discord MegaBot is ready to serve! 🚀**

Made with ❤️ - Happy hosting!
