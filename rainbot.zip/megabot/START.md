# 🚀 QUICK START GUIDE - Ultimate Discord MegaBot

## ⚡ Installation (5 Minutes)

### Step 1: Install Node.js
```bash
# Check if Node.js is installed
node --version

# If not installed, download from: https://nodejs.org/
# Required: Node.js 18.0.0 or higher
```

### Step 2: Clone & Install
```bash
cd /home/claude/megabot
npm install
```

### Step 3: Create Discord Bot
1. Go to https://discord.com/developers/applications
2. Click "New Application"
3. Go to "Bot" tab → Click "Add Bot"
4. Enable these Privileged Gateway Intents:
   - ✅ PRESENCE INTENT
   - ✅ SERVER MEMBERS INTENT
   - ✅ MESSAGE CONTENT INTENT
5. Copy the bot token

### Step 4: Configure Bot
```bash
cp .env.example .env
nano .env
```

Add your bot token:
```env
DISCORD_TOKEN=your_bot_token_here
PREFIX=!
OWNER_IDS=your_discord_user_id
```

Save (Ctrl+X, Y, Enter)

### Step 5: Invite Bot to Server
1. Go to "OAuth2" → "URL Generator" in Discord Developer Portal
2. Select scopes:
   - ✅ bot
   - ✅ applications.commands
3. Select permissions:
   - ✅ Administrator (or select specific permissions)
4. Copy the generated URL and open in browser
5. Select your server and authorize

### Step 6: Start the Bot
```bash
npm start
```

## 🎯 First Commands

Once the bot is online in your server:

```
!help              # View all commands
!setup             # Interactive setup wizard
!ticketsetup       # Setup ticket system
!ping              # Check if bot is working
```

## 📋 Complete Setup Checklist

### Essential Setup
- [x] `!setup` - Run the main setup wizard
- [ ] Configure ticket system
- [ ] Set up logging channels
- [ ] Configure welcome/goodbye messages
- [ ] Enable auto-moderation
- [ ] Set up leveling system

### Recommended Setup
- [ ] Create custom shop items
- [ ] Set up reaction roles
- [ ] Configure auto-roles
- [ ] Set up starboard
- [ ] Configure economy settings

## 🎫 Ticket System Setup

```
!ticketsetup
```

1. Click "Add Green Button" / "Add Blue Button" etc.
2. Configure category details (Title, Description, Color)
3. Click "FINISH" when done
4. Provide the channel where ticket panel should be posted
5. ✅ Done! Users can now create tickets

## 🛡️ Moderation Commands

```
!clear 50                    # Delete 50 messages
!kick @user reason           # Kick a user
!ban @user reason            # Ban a user
!warn @user reason           # Warn a user
!mute @user 1h reason        # Mute for 1 hour
!lock                        # Lock channel
!slowmode 5s                 # Set slowmode
```

## 💰 Economy Commands

```
!daily                       # Claim daily reward
!work                        # Work for coins
!balance                     # Check balance
!rob @user                   # Rob another user
!deposit all                 # Deposit to bank
!leaderboard coins           # View top users
```

## 🎮 Fun & Games

```
!8ball <question>            # Ask the magic 8ball
!coinflip                    # Flip a coin
!dice                        # Roll a dice
!meme                        # Get a random meme
!joke                        # Get a joke
```

## 💻 VPS Commands (Admin Only - BE CAREFUL!)

```
!bash sudo apt update        # Execute system commands
!sshx                        # Create SSH session with web access
!tmate                        # Alternative SSH sharing
```

**⚠️ WARNING**: VPS commands give direct system access. Only use if you understand the risks!

## 📊 Leveling System

- Users gain XP by chatting
- Set level-up announcement channel
- Configure level roles
- View rank with `!rank`
- Check leaderboard with `!leaderboard`

## 🎁 Giveaways

```
!giveaway 1h 1 Discord Nitro    # Start 1-hour giveaway
!gend <message_id>              # End early
!greroll <message_id>           # Reroll winner
```

## 📊 Polls

```
!poll Question | Option 1 | Option 2 | Option 3
```

## ⏰ Reminders

```
!remind 30m Take a break
!remind 1h Check Discord
!remind 1d Study for exam
```

## 🚨 Troubleshooting

### Bot Not Responding
1. Check if bot is online (green status)
2. Verify Message Content Intent is enabled
3. Check bot has proper permissions
4. Try `!ping` to test

### Commands Not Working
1. Check prefix with `!help`
2. Verify you have required permissions
3. Make sure bot role is high enough in role hierarchy

### Database Errors
```bash
cd /home/claude/megabot
rm -rf data/megabot.db
npm start
# Database will be recreated
```

## 📚 Command Categories

The bot includes 500+ commands across these categories:

- 🛠️ **Setup** - Server configuration
- 🎫 **Tickets** - Support ticket system
- 🛡️ **Moderation** - Moderation tools
- 💰 **Economy** - Virtual economy
- 📊 **Leveling** - XP and ranks
- 🎮 **Fun** - Fun commands and games
- 🔧 **Utility** - Useful tools
- 🎁 **Giveaways** - Giveaway management
- 📊 **Polls** - Create polls
- ⏰ **Reminders** - Set reminders
- 💻 **VPS** - System management (Admin)
- And many more!

## 🆘 Support

Need help? Join our support server or create a GitHub issue!

- Support Server: [Your Discord Server]
- GitHub Issues: [Your GitHub Repo]
- Documentation: Run `!help` in Discord

## 🔄 Keeping Bot Updated

```bash
cd /home/claude/megabot
git pull
npm install
npm start
```

## 💡 Pro Tips

1. **Use `!setup` first** - This configures essential features
2. **Set up logging** - Monitor what happens in your server
3. **Configure auto-mod** - Prevent spam and rule violations
4. **Customize economy** - Adjust rewards and shop items
5. **Use VPS commands carefully** - They have full system access

## 🎉 You're All Set!

Your bot is now ready to use with 500+ commands!

Type `!help` in your Discord server to explore all features.

---

Made with ❤️ by the MegaBot Team
